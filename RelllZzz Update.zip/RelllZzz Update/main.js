/*
   * Script Dii WhatsApp - Bot
   * Created By DiiOffc 
*/

require('./settings')
const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, generateWAMessageFromContent, downloadContentFromMessage, makeInMemoryStore, proto, jidDecode, PHONENUMBER_MCC } = require('@whiskeysockets/baileys')
const pino = require('pino')
const fs = require('fs')
const chalk = require('chalk')
const path = require('path')
const FileType = require('file-type')
const readline = require('readline')
const yargs = require('yargs/yargs')
const _ = require('lodash')
const PhoneNumber = require('awesome-phonenumber')
const spinnies = new (require('spinnies'))()
const { imageToWebp, videoToWebp, writeExifImg, writeExifVid } = require('./lib/scraper')
const { getFile, getBuffer, metaAudio, smsg } = require('./lib/myfunc')

const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) })

const parseMention = text => [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net')

const question = (text) => { const rl = readline.createInterface({ input: process.stdin, output: process.stdout }); return new Promise((resolve) => { rl.question(text, resolve) }) }

var low
try {
low = require('lowdb')
} catch (e) {
low = require('./lib/lowdb')
}

const { Low, JSONFile } = low
const mongoDB = require('./lib/mongoDB')

global.opts = new Object(yargs(process.argv.slice(2)).exitProcess(false).parse())
global.db = new Low(
  /https?:\/\//.test(opts['db'] || '') ?
    new cloudDBAdapter(opts['db']) : /mongodb/.test(opts['db']) ?
      new mongoDB(opts['db']) :
      new JSONFile(`database/database.json`)
)
global.DATABASE = global.db // Backwards Compatibility
global.loadDatabase = async function loadDatabase() {
  if (global.db.READ) return new Promise((resolve) => setInterval(function () { (!global.db.READ ? (clearInterval(this), resolve(global.db.data == null ? global.loadDatabase() : global.db.data)) : null) }, 1 * 1000))
  if (global.db.data !== null) return
  global.db.READ = true
  await global.db.read()
  global.db.READ = false
  global.db.data = {
    users: {},
    chats: {},
    settings: {},
    ...(global.db.data || {})
  }
  global.db.chain = _.chain(global.db.data)
}
loadDatabase()

if (global.db) setInterval(async () => {
    if (global.db.data) await global.db.write()
  }, 30 * 1000)
  
setInterval(async () => {
const directoryPath = `./${sessionName}`
fs.readdir(directoryPath, (err, files) => {
if (err) {
console.log('Error reading directory:', err)
return
}
files.forEach((file) => {
const filePath = path.join(directoryPath, file)
const fileStat = fs.statSync(filePath);
const currentTime = new Date().getTime()
const fileModifiedTime = fileStat.mtime.getTime()
const timeDifference = currentTime - fileModifiedTime
const oneHourInMilliseconds = 1800000
if (timeDifference >= oneHourInMilliseconds && file !== 'creds.json') {
fs.unlink(filePath, (err) => {
if (err) {
return console.log('Error deleting file:', err)
}
console.log('Sampah Session Berhasil Dibersihkan.')
})}
})
})
}, 10 * 1000)

async function connectToWhatsApp() {
    const { state, saveCreds } = await useMultiFileAuthState(`./${sessionName}`);
    const conn = makeWASocket({
        logger: pino({ level: 'silent' }),
        printQRInTerminal: !state,
        patchMessageBeforeSending: (message) => {
            const requiresPatch = !!(message.buttonsMessage || message.templateMessage || message.listMessage);
            if (requiresPatch) {
                message = {
                    viewOnceMessage: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadataVersion: 2,
                                deviceListMetadata: {},
                            },
                            ...message,
                        },
                    },
                };
            }
            return message;
        },
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        version: [2, 3000, 1015901307],
        auth: state,
    });
    spinnies.add('start', { text: 'Connecting . . .' });
    if (state && !conn.authState.creds.registered) {
        console.log(chalk.black(chalk.redBright(`Enter Mobile Number`)))
        let phoneNumber = await question(`${chalk.bgBlack('- Number')}: `);
        phoneNumber = phoneNumber.replace(/[^0-9]/g, '')
        if (!Object.keys(PHONENUMBER_MCC).some(v => String(phoneNumber).startsWith(v))) {
            spinnies.fail('start', { text: 'Invalid number, start with country code (Example: 62xxx)' });
            process.exit(0);
        }
            try {
                let code = await conn.requestPairingCode(phoneNumber);
                code = code.match(/.{1,4}/g)?.join("-") || code;
                console.log(chalk.black(chalk.bgGreen('Your Pairing Code')), ' : ' + chalk.black(chalk.white(code)));
            } catch (error) {
                console.error('Error requesting pairing code:', error);
            }
    }

store.bind(conn.ev)

conn.ev.on('messages.upsert', async chatUpdate => {
try {
mek = chatUpdate.messages[0]
if (!mek.message) return
mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage') ? mek.message.ephemeralMessage.message : mek.message
if (mek.key && mek.key.remoteJid === 'status@broadcast') return
if (!conn.public && !mek.key.fromMe && chatUpdate.type === 'notify') return
if (mek.key.id.startsWith('BAE5') && mek.key.id.length === 16) return
m = smsg(conn, mek, store)
require("./message")(conn, m, chatUpdate, store)
} catch (err) {
console.log(err)
}
})

conn.decodeJid = (jid) => {
if (!jid) return jid
if (/:\d+@/gi.test(jid)) {
let decode = jidDecode(jid) || {}
return decode.user && decode.server && decode.user + '@' + decode.server || jid
} else return jid
}

conn.ev.on('contacts.update', update => {
for (let contact of update) {
let id = conn.decodeJid(contact.id)
if (store && store.contacts) store.contacts[id] = { id, name: contact.notify }}})

conn.getName = (jid, withoutContact  = false) => {
id = conn.decodeJid(jid)
withoutContact = conn.withoutContact || withoutContact 
let v
if (id.endsWith("@g.us")) return new Promise(async (resolve) => {
v = store.contacts[id] || {}
if (!(v.name || v.subject)) v = conn.groupMetadata(id) || {}
resolve(v.name || v.subject || PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international'))
})
else v = id === '0@s.whatsapp.net' ? {
id,
name: 'WhatsApp'
} : id === conn.decodeJid(conn.user.id) ?
conn.user :
(store.contacts[id] || {})
return (withoutContact ? '' : v.name) || v.subject || v.verifiedName || PhoneNumber('+' + jid.replace('@s.whatsapp.net', '')).getNumber('international')}

conn.ev.on('group-participants.update', async (anu) => {
console.log(anu)
try {
let metadata = await conn.groupMetadata(anu.id)
let participants = anu.participants
let namagc = metadata.subject
for (let num of participants) {
let check = anu.author !== num && anu.author.length > 1
let tag = check ? [anu.author, num] : [num]
// Get Profile Picture User
try {
ppuser = await conn.profilePictureUrl(num, 'image')
} catch {
ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}
// Get Profile Picture Group
try {
ppgroup = await conn.profilePictureUrl(anu.id, 'image')
} catch {
ppgroup = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}
if (global.db.data.chats[m.chat].welcome && anu.action == 'add') {
conn.sendMessage(anu.id, {text: check ? `@${anu.author.split("@")[0]} Telah Menambahkan @${num.split("@")[0]} Ke Dalam Di *${namagc}*` : `Hallo Kak @${num.split("@")[0]} Selamat Datang Di *${namagc}*

----------------------------------

*Masuk Sini Kak*

*Link Gc :*
${global.linkgc}

*Informasi seputar RellllZzz BOTZ*`,
contextInfo: {mentionedJid: [...tag], externalAdReply: { thumbnailUrl: ppuser, title: '© Welcome Message', body: '', renderLargerThumbnail: true, sourceUrl: global.linkgc, mediaType: 1}}})
} else if (global.db.data.chats[m.chat].goodbye && anu.action == 'remove') {
conn.sendMessage(anu.id, {text: check ? `@${anu.author.split("@")[0]} Telah Mengeluarkan @${num.split("@")[0]} Dari Di *${namagc}*` : `@${num.split("@")[0]} Telah Keluar Dari Di *${namagc}*

----------------------------------

*Masuk Sini Kak*

*Link Gc :*
${global.linkgc}

*Informasi seputar RellllZzz-BOTZ*`,
contextInfo: {mentionedJid: [...tag], externalAdReply: { thumbnailUrl: ppuser, title: '© Leaving Message', body: '', renderLargerThumbnail: true, sourceUrl: global.linkgc, mediaType: 1}}})
} else if (global.db.data.chats[m.chat].promote && anu.action == 'promote') {
conn.sendMessage(anu.id, {text: `@${anu.author.split("@")[0]} Telah Menjadikan @${num.split("@")[0]} Sebagai Admin Di *${namagc}*

----------------------------------

*Masuk Sini Kak*

*Link Gc :*
${global.linkgc}

*Informasi seputar RellllZzz-BOTZ*`,
contextInfo: {mentionedJid: [...tag], externalAdReply: { thumbnailUrl: ppuser, title: '© Promote Message', body: '', renderLargerThumbnail: true, sourceUrl: global.linkgc, mediaType: 1}}})
} else if (global.db.data.chats[m.chat].demote && anu.action == 'demote') {
conn.sendMessage(anu.id, {text: `@${anu.author.split("@")[0]} Telah Memberhentikan @${num.split("@")[0]} Sebagai Admin Di *${namagc}*

----------------------------------

*Masuk Sini Kak*

*Link Gc :*
${global.linkgc}

*Informasi seputar RelllZzz-BOTZ*`,
contextInfo: {mentionedJid: [...tag], externalAdReply: { thumbnailUrl: ppuser, title: '© Demote Message', body: '', renderLargerThumbnail: true, sourceUrl: global.linkgc, mediaType: 1}}})
}
}
} catch (err) {
console.log(err)
}
})

conn.public = true

conn.ev.on('creds.update', saveCreds)

conn.reply = async (jid, text, quoted, options) => {
        await conn.sendPresenceUpdate('composing', jid)
        return conn.sendMessage(jid, {text: text, mentions: parseMention(text), ...options}, { quoted})
        }
     
conn.sendFile = async (jid, url, name, caption = '', quoted, opts, options) => {
const {
status,
file,
filename,
mime,
size,
extension
} = await getFile(url, name, opts && opts.referer ? opts.referer : false)
if (!status) return conn.reply(jid, `Failed to proccess file.`, quoted)
conn.refreshMediaConn(false)
if (opts && opts.document) {
await conn.sendPresenceUpdate('composing', jid)
const process = await metaAudio(file, {
title: filename.replace(new RegExp('.mp3', 'i'), ''),
...tags,
APIC: opts && opts.APIC ? opts.APIC : tags.APIC
})
return conn.sendMessage(jid, {
document: {
url: extension == 'm4a' ? file : process.file
},
fileName: filename,
mimetype: mime,
caption: caption,
...options
}, {
quoted
})
} else {
if (/image\/(jpe?g|png)/.test(mime)) {
await conn.sendPresenceUpdate('composing', jid)
return conn.sendMessage(jid, {
image: {
url: file
},
caption: caption,
mentions: [...caption.matchAll(/@(\d{0,16})/g)].map(v => v[1] + '@s.whatsapp.net'),
...options
}, {
quoted
})
} else if (/video/.test(mime)) {
await conn.sendPresenceUpdate('composing', jid)
return conn.sendMessage(jid, {
video: {
url: file
},
caption: caption,
gifPlayback: opts && opts.gif ? true : false,
mentions: [...caption.matchAll(/@(\d{0,16})/g)].map(v => v[1] + '@s.whatsapp.net'),
...options
}, {
quoted
})
} else if (/audio/.test(mime)) {
await conn.sendPresenceUpdate(opts && opts.ptt ? 'recoding' : 'composing', jid)
const process = await metaAudio(file, {
title: filename.replace(new RegExp('.mp3', 'i'), ''),
...tags,
APIC: opts && opts.APIC ? opts.APIC : tags.APIC
})
return conn.sendMessage(jid, {
audio: {
url: extension == 'm4a' ? file : process.file
},
ptt: opts && opts.ptt ? true : false,
waveform: opts && opts.ptt ? [0,0,15,0,0] : [],
mimetype: mime,
mentions: [...caption.matchAll(/@(\d{0,16})/g)].map(v => v[1] + '@s.whatsapp.net'),
...options
}, {
quoted
})
} else {
await conn.sendPresenceUpdate('composing', jid)
return conn.sendMessage(jid, {
document: {
url: file
},
fileName: filename,
mimetype: mime,
caption: caption,
...options
}, {
quoted
})
}
}
}

conn.sendContact = async (jid, kon, desk = "Developer Bot", quoted = '', opts = {}) => {
let list = []
for (let i of kon) {
list.push({
displayName: global.ownername,
  vcard: 'BEGIN:VCARD\n' +
    'VERSION:3.0\n' +
    `N:;${global.ownername};;;\n` +
    `FN:${global.ownername}\n` +
    'ORG:null\n' +
    'TITLE:\n' +
    `item1.TEL;waid=${i}:${i}\n` +
    'item1.X-ABLabel:Ponsel\n' +
    `X-WA-BIZ-DESCRIPTION:${desk}\n` +
    `X-WA-BIZ-NAME:${global.ownername}\n` +
    'END:VCARD'
})
}
conn.sendMessage(jid, { contacts: { displayName: `${list.length} Kontak`, contacts: list }, ...opts }, { quoted })
}

conn.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
        let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
        let buffer
        if (options && (options.packname || options.author)) {
            buffer = await writeExifImg(buff, options)
        } else {
            buffer = await imageToWebp(buff)
        }

        await conn.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted })
        return buffer
    }    
    
conn.sendVideoAsSticker = async (jid, path, quoted, options = {}) => {
        let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
        let buffer
        if (options && (options.packname || options.author)) {
            buffer = await writeExifVid(buff, options)
        } else {
            buffer = await videoToWebp(buff)
        }

        await conn.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted })
        return buffer
    }
    
conn.downloadMediaMessage = async (message) => {
       let mime = (message.msg || message).mimetype || ''
       let messageType = message.mtype ? message.mtype.replace(/Message|WithCaption/gi, '') : mime.split('/')[0]
       const stream = await downloadContentFromMessage(message, messageType)
       let buffer = Buffer.from([])
       for await (const chunk of stream) {
       buffer = Buffer.concat([buffer, chunk])
       }
       return buffer
       }    
    
conn.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
    let quoted = message.msg ? message.msg : message
    let mime = (message.msg || message).mimetype || ''
    let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
    const stream = await downloadContentFromMessage(quoted, messageType)
    let buffer = Buffer.from([])
    for await (const chunk of stream) {
      buffer = Buffer.concat([buffer, chunk])
    }
    let type = await FileType.fromBuffer(buffer)
    trueFileName = attachExtension ? (filename + '.' + type.ext) : filename
    // save to file
    await fs.writeFileSync(trueFileName, buffer)
    return trueFileName
  }

conn.serializeM = (m) => smsg(conn, m, store)
conn.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === 'connecting') {
        } else if (connection === 'open') {
            spinnies.succeed('start', { text: `Connected, you login as ${conn.user.name || conn.user.verifiedName || 'WhatsApp Bot'}` });
        } else if (connection === 'close') {
            if (lastDisconnect.error.output.statusCode === DisconnectReason.loggedOut) {
                spinnies.fail('start', { text: `Can't connect to Web Socket` });
                connectToWhatsApp()
                process.exit(0);
            } else {
                connectToWhatsApp().catch(() => connectToWhatsApp());
            }
        }
    });

return conn
}

connectToWhatsApp()

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})