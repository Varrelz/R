/*
   * Script Dii WhatsApp - Bot
   * Created By DiiOffc 
*/

process.on('uncaughtException', console.error)
require('./settings')
const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys')
const fs = require('fs')
const os = require('os')
const path = require('path')
const chalk = require('chalk')
const util = require('util')
const axios = require('axios')
const fetch = require('node-fetch')
const ffmpeg = require('fluent-ffmpeg')
const { performance } = require('perf_hooks')
const { exec, execSync } = require('child_process')
const jimp = require('jimp')
const moment = require('moment-timezone')
const crypto = require('crypto')
const canvafy = require('canvafy')
const ytSearch = require('yt-search')
const { latinToAksara } = require('@bochilteam/scraper')
const { aksaraToLatin } = require('@bochilteam/scraper')
const { translate } = require("@vitalets/google-translate-api")
const googleSearch = require('google-it')
const dylux = require('api-dylux')
const dann = require('d-scrape')
const noTelp = require('no-telp')
const malScraper = require('mal-scraper')
const { checkBandwidth, runtime, formatIDR, toRupiah, msToDate, msToDay, capital, fetchJson, randomNumber, toNumber, sort, enumGetKey, generateProfilePicture, sleep, pickRandom, clockString, formatSize, getRandom, isUrl } = require('./lib/myfunc')
const { pinterest, openai, bardaifree, fetchWeather, jarakkota, CapCut, addExif, remini, dellCase, listCase, getCase, blackboxChat, stickersearch, searchAnime, webp2mp4, toAudio, toPTT, mediafire } = require('./lib/scraper')
const { catbox } = require('./lib/uploader')

//================== [ DATABASE GAME ] ==================//
let databasetictactoe = {}
let databasesuit = {}
let databasetebakbomb = {}

module.exports = conn = async (conn, m, chatUpdate, store) => {
try {
const body = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype == 'interactiveResponseMessage') ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id : (m.mtype == 'templateButtonReplyMessage') ? m.msg.selectedId : (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
const budy = (typeof m.text == 'string' ? m.text : '')

const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><`™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : '.'
const isCmd = body.startsWith(prefix);
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '';
const cmd = prefix + command
const args = body.trim().split(/ +/).slice(1)
const botNumber = await conn.decodeJid(conn.user.id)
const isCreator = m.sender == owner+"@s.whatsapp.net" ? true : m.fromMe ? true : false
const text = q = args.join(" ")
const from = mek.key.remoteJid
const quoted = m.quoted ? m.quoted : m
const qmsg = (quoted.msg || quoted)
const mime = (quoted.msg || quoted).mimetype || ''
const pushname = m.pushName || "No Name"

//================== [ GROUP ] ==================//
const groupMetadata = m.isGroup ? await conn.groupMetadata(m.chat).catch(e => {}) : {}
let participant_bot = m.isGroup ? groupMetadata?.participants.find((v) => v.id == botNumber) : {}
let participant_sender = m.isGroup ? groupMetadata?.participants.find((v) => v.id == m.sender) : {}
const isBotAdmins = participant_bot?.admin !== null ? true : false
const isAdmins = participant_sender?.admin !== null ? true : false

//================== [ WAKTU ] ==================//
const time = moment().tz('Asia/Makassar').format('HH:mm:ss')

if(time < "23:59:00"){
var ucapanWaktu = 'Selamat Malam 🏙️'
}
if(time < "19:00:00"){
var ucapanWaktu = 'Selamat Petang 🌆'
}
if(time < "18:00:00"){
var ucapanWaktu = 'Selamat Sore 🌇'
}
if(time < "15:00:00"){
var ucapanWaktu = 'Selamat Siang 🌤️'
}
if(time < "10:00:00"){
var ucapanWaktu = 'Selamat Pagi 🌄'
}
if(time < "05:00:00"){
var ucapanWaktu = 'Selamat Subuh 🌆'
}
if(time < "03:00:00"){
var ucapanWaktu = 'Selamat Tengah Malam 🌃'
}

let d = new Date(new Date() + 3600000);
let locale = "id";
const jam = new Date().toLocaleString("en-US", {
timeZone: "Asia/Makassar",
});
const tgl = d.toLocaleDateString(locale, {
day: "numeric",
month: "long",
year: "numeric",
});
const hari = d.toLocaleDateString(locale, { weekday: "long" })

//================== [ PROFIL ] ==================//
var ppuser
try {
ppuser = await conn.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://telegra.ph/file/a059a6a734ed202c879d3.jpg'
}

//================== [ QUOTED ] ==================//
const qtoko = {
key: {
fromMe: false,
participant: `${owner}@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
}, message: {
"productMessage": {
"product": {
"productImage": {
"mimetype": "image/jpeg",
"jpegThumbnail": "",
},
"title": `${global.ownername} - Marketplace`,
"description": null,
"currencyCode": "IDR",
"priceAmount1000": "999999999999999",
"retailerId": `© Copyright ${global.ownername}`,
"productImageCount": 1
},
"businessOwnerJid": `${owner}@s.whatsapp.net`
}}
}

//================== [ EXAMPLE ] ==================//
const example = (teks) => {
return `Contoh : *${cmd}* ${teks}`
}

//================== [ DATABASE ] ==================//
try {
let isNumber = x => typeof x === 'number' && !isNaN(x)
let user = global.db.data.users[m.sender]
if (typeof user !== 'object') global.db.data.users[m.sender] = {}
if (user) {
if (!('name' in user)) user.name = ''
if (!('registered' in user)) user.registered = false
if (!('sn' in user)) user.sn = ''
if (!isNumber(user.limit)) user.limit = limitawal
if (!isNumber(user.balance)) user.balance = balanceawal
if (!('banned' in user)) user.banned = false
if (!('premium' in user)) user.premium = false
if (!isNumber(user.afk)) user.afk = -1
if (!('afkAlasan' in user)) user.afkAlasan = ''
} else global.db.data.users[m.sender] = {
name: '',
registered: false,
sn: '',
limit: limitawal,
balance: balanceawal,
banned: false,
premium: false,
afk: -1, 
afkAlasan: '',
}

let chats = global.db.data.chats[m.chat]
if (typeof chats !== 'object') global.db.data.chats[m.chat] = {}
if (chats) {
if (!('panel' in chats)) chats.panel = false
if (!('subdo' in chats)) chats.subdo = false
if (!('welcome' in chats)) chats.welcome = true
if (!('goodbye' in chats)) chats.goobye = true
if (!('promote' in chats)) chats.promote = true
if (!('demote' in chats)) chats.demote = true
} else global.db.data.chats[m.chat] = {
panel: false,
subdo: false,
welcome: true,
goodbye: true,
promote: true,
demote: true,
}

let settings = global.db.data.settings[botNumber]
if (typeof settings !== 'object') global.db.data.settings[botNumber] = {}
if (settings) {
} else global.db.data.settings[botNumber] = {

}
} catch (err) {
console.error(err)
}

if(!('error' in db.data.settings)) db.data.settings.error = []

const isPremium = db.data.users[m.sender].premium == true ? true : m.sender == owner ? true : false
const panel = db.data.chats[m.chat].panel ? true : false
const subdo = db.data.chats[m.chat].subdo ? true : false
const limitnya = db.data.users[m.sender].limit
const balancenya = db.data.users[m.sender].balance

async function uselimit() {
if (isCreator) return
db.data.users[m.sender].limit -= 1
}

//================== [ AFK USER ] ==================//
if (db.data.users[m.sender].afk > -1) {
let orang = db.data.users[m.sender]
await conn.sendMessage(m.chat, {text: `@${m.sender.split('@')[0]} _Telah kembali dari AFK_\nSetelah *${db.data.users[m.sender].afkAlasan}*\n\n*Waktu Afk :* ${clockString(new Date - orang.afk)}`.trim(), contextInfo: {mentionedJid: [m.sender]}}, {quoted: m})
orang.afk = -1
orang.afkAlasan = ''
}

//================== [ BANNED USER ] ==================//
if (isCmd && db.data.users[m.sender].banned == true) return m.reply(mess.banned)

//================== [ ERROR FEATURE ] ==================//
if (db.data.settings.error.includes(command)) return m.reply("❗Fitur ini sedang di perbaiki *Owner*, karna terjadi *Error*")

//================== [ CONSOLE LOG ] ==================//
if (m.message) {
if (isCmd && !m.isGroup) {
console.log(chalk.black(chalk.bgHex('#ff5e78').bold(`\n🌟 ${ucapanWaktu} 🌟`)));
console.log(chalk.white(chalk.bgHex('#4a69bd').bold(`🚀 Ada Pesan, Kak ${ownername} 🚀`)));
console.log(chalk.black(chalk.bgHex('#fdcb6e')(`📅 DATE: ${jam}
👤 SENDERNAME: ${pushname}
💬 MESSAGE: ${m.body || m.mtype}`)));
}
}

//================== [ TOTAL FITUR ] ==================//
const totalFitur = () =>{
var mytext = fs.readFileSync("./message.js").toString()
var numUpper = (mytext.match(/case '/g) || []).length;
return numUpper
}

//================== [ GAME ] ==================//
const isTicTacToe = (from, _dir) => {
let status = false
Object.keys(_dir).forEach((i) => {
if (_dir[i].id === from) {
status = true
}
})
return status
}
const getPosTic = (from, _dir) => {
let position = null
Object.keys(_dir).forEach((i) => {
if (_dir[i].id === from) {
position = i
}
})
if (position !== null) {
return position
}
}
const KeisiSemua = (tic) => {
let status = true
for (let i of tic){
if (i !== '❌' && i !== '⭕'){
status = false
}
}
return status
}
const cekIsi = (nomor, tic) => {
let status = false
if (tic[nomor] === '❌' || tic[nomor] === '⭕'){
status = true
}
return status
}
const cekTicTac = (tic) => {
let status = false
if (tic[0] === '❌' && tic[1] === '❌' && tic[2] === '❌' || tic[0] === '⭕' && tic[1]=== '⭕' && tic[2] === '⭕'){
status = true
} else if (tic[3] === '❌' && tic[4] === '❌' && tic[5] === '❌' || tic[3] === '⭕' && tic[4] === '⭕' && tic[5] === '⭕'){
status = true
} else if (tic[6] === '❌' && tic[7] === '❌' && tic[8] === '❌' || tic[6] === '⭕' && tic[7] === '⭕' && tic[8] === '⭕'){
status = true
} else if (tic[0] === '❌' && tic[3] === '❌' && tic[6] === '❌' || tic[0] === '⭕' && tic[3] === '⭕' && tic[6] === '⭕'){
status = true
} else if (tic[1] === '❌' && tic[4] === '❌' && tic[7] === '❌' || tic[1] === '⭕' && tic[4] === '⭕' && tic[7] === '⭕'){
status = true
} else if (tic[2] === '❌' && tic[5] === '❌' && tic[8] === '❌' || tic[2] === '⭕' && tic[5] === '⭕' && tic[8] === '⭕'){
status = true
} else if (tic[0] === '❌' && tic[4] === '❌' && tic[8] === '❌' || tic[0] === '⭕' && tic[4] === '⭕' && tic[8] === '⭕'){
status = true
} else if (tic[2] === '❌' && tic[4] === '❌' && tic[6] === '❌' || tic[2] === '⭕' && tic[4] === '⭕' && tic[6] === '⭕'){
status = true
}
return status 
}
if (isTicTacToe(from, databasetictactoe)) {
try {
// TicTacToe
if (isTicTacToe(from, databasetictactoe)){
let nomor = [1, 2, 3, 4, 5, 6, 7, 8, 9]
let posi = databasetictactoe[from]
let anu = posi.TicTacToe
if (posi.status === null){
if (sender === posi.ditantang){
if (body.toLowerCase() === 'y'){
the = `@${posi.ditantang.split('@')[0]} menerima tantangan

@${posi.penantang.split('@')[0]} = ❌
@${posi.ditantang.split('@')[0]} = ⭕

${anu[0]}${anu[1]}${anu[2]}
${anu[3]}${anu[4]}${anu[5]}
${anu[6]}${anu[7]}${anu[8]}

Giliran @${posi.penantang.split('@')[0]}`
conn.sendMessage(from, { text: the }, { quoted: m })

databasetictactoe[from].status = true
} else if (body.toLowerCase() === 'n'){
db.data.users[m.sender].balance -= 100
the1 = `@${posi.ditantang.split('@')[0]} menolak, game dibatalkan\nDan Player dikenakan sanksi -100 balance karna menolak ajakan pemain`
conn.sendMessage(from, { text: the1 }, { quoted: m })
delete databasetictactoe[from];
}
}
} else if (posi.status === true){
if (sender === posi.penantang){
for (let i of nomor){
if (Number(body) === i){
if (cekIsi(Number(body) - 1, anu)) return m.reply(`Nomor tersebut sudah terisi`)
databasetictactoe[from].TicTacToe[Number(body) - 1] = '❌'
if (cekTicTac(databasetictactoe[from].TicTacToe)){
the2 = `@${posi.penantang.split('@')[0]} Menang

@${posi.penantang.split('@')[0]} = ❌
@${posi.ditantang.split('@')[0]} = ⭕

${anu[0]}${anu[1]}${anu[2]}
${anu[3]}${anu[4]}${anu[5]}
${anu[6]}${anu[7]}${anu[8]}

Hadiah : ${posi.hadiah} balance
Ingin bermain lagi? ${prefix}tictactoe`
conn.sendMessage(from, { text: the2 }, { quoted: m })
global.db.data.users[posi.penantang].balance += posi.hadiah
global.db.data.users[posi.ditantang].balance -= posi.hadiah
delete databasetictactoe[from];
} else if (KeisiSemua(anu)) {
the3 = `*HASIL SERI*

@${posi.penantang.split('@')[0]} = ❌
@${posi.ditantang.split('@')[0]} = ⭕

${anu[0]}${anu[1]}${anu[2]}
${anu[3]}${anu[4]}${anu[5]}
${anu[6]}${anu[7]}${anu[8]}

Ingin bermain lagi? ${prefix}tictactoe`
conn.sendMessage(from, { text: the3 }, { quoted: m })

delete databasetictactoe[from];
} else {
the4 = `@${posi.penantang.split('@')[0]} telah mengisi

@${posi.penantang.split('@')[0]} = ❌
@${posi.ditantang.split('@')[0]} = ⭕

${anu[0]}${anu[1]}${anu[2]}
${anu[3]}${anu[4]}${anu[5]}
${anu[6]}${anu[7]}${anu[8]}

Giliran @${posi.ditantang.split('@')[0]}`
conn.sendMessage(from, { text: the4 }, { quoted: m })

databasetictactoe[from].status = false
}
}
}
}
} else if (posi.status === false){
if (sender === posi.ditantang){
for (let i of nomor){
if (Number(body) === i){
if (cekIsi(Number(body) - 1, anu)) return m.reply(`Nomor tersebut sudah terisi`)
databasetictactoe[from].TicTacToe[Number(body) - 1] = '⭕' 
if (cekTicTac(anu)){
the5 = `@${posi.ditantang.split('@')[0]} Menang

@${posi.penantang.split('@')[0]} = ❌
@${posi.ditantang.split('@')[0]} = ⭕

${anu[0]}${anu[1]}${anu[2]}
${anu[3]}${anu[4]}${anu[5]}
${anu[6]}${anu[7]}${anu[8]}

Hadiah : ${posi.hadiah} balance
Ingin bermain lagi? ${prefix}tictactoe`
conn.sendMessage(from, { text: the5 }, { quoted: m })
global.db.data.users[posi.ditantang].balance += posi.hadiah
global.db.data.users[posi.penantang].balance -= posi.hadiah
delete databasetictactoe[from];
} else if (KeisiSemua(anu)) {
the6 = `Hasil Seri

@${posi.penantang.split('@')[0]} = ❌
@${posi.ditantang.split('@')[0]} = ⭕

${anu[0]}${anu[1]}${anu[2]}
${anu[3]}${anu[4]}${anu[5]}
${anu[6]}${anu[7]}${anu[8]}

Ingin bermain lagi? ${prefix}tictactoe`
conn.sendMessage(from, { text: the6 }, { quoted: m })

delete databasetictactoe[from];
} else {
the7 = `@${posi.ditantang.split('@')[0]} telah mengisi

@${posi.penantang.split('@')[0]} = ❌
@${posi.ditantang.split('@')[0]} = ⭕

${anu[0]}${anu[1]}${anu[2]}
${anu[3]}${anu[4]}${anu[5]}
${anu[6]}${anu[7]}${anu[8]}

Giliran @${posi.penantang.split('@')[0]}`
conn.sendMessage(from, { text: the7 }, { quoted: m })

databasetictactoe[from].status = true
}
}
}
}
}
}
} catch (err) {
console.log(chalk.redBright('[ ERROR TICTACTOE ]'), err)
}
}

try {
let roof = Object.values(databasesuit).find(v => v.status && [v.penantang, v.ditantang].includes(m.sender))
if (roof) {
let win = ''
let tie = false
if (m.sender == roof.ditantang && isGroup && roof.status == 'WAIT') {
if (body.toLowerCase() === 'y') {
roof.status = 'PLAY'
roof.asal = m.chat
clearTimeout(roof.waktu)
await conn.sendMessage(m.chat, {text: 'Suit telah dikirimkan ke chat\nSilahkan pilih suit di chat masing²', contextInfo: {mentionedJid: [roof.ditantang, roof.penantang]}}, {quoted: m})
if (!roof.pilih1) await conn.sendMessage(roof.penantang, { text: `*Silahkan pilih dibawah ini :*\n✂ Gunting\n📄 Kertas\n🗿 Batu\n\nContoh jika kamu ingin memilih gunting ketik *Gunting*` }, { quoted: m })
if (!roof.pilih2) await conn.sendMessage(roof.ditantang, { text: `*Silahkan pilih dibawah ini :*\n✂ Gunting\n📄 Kertas\n🗿 Batu\n\nContoh jika kamu ingin memilih gunting ketik *Gunting*` }, { quoted: m })
roof.waktu_milih = setTimeout(async() => {
if (!roof.pilih && !roof.pilih2) await conn.sendMessage(m.chat, {text: `Kedua pemain tidak niat main!\nGame suit dibatalkan`})
else if (!roof.pilih || !roof.pilih2) {
win = !roof.pilih ? roof.ditantang : roof.penantang
await conn.sendMessage(m.chat, {text: `@${(roof.pilih ? roof.ditantang : roof.penantang).split('@')[0]} tidak memilih suit\nGame suit dibatalkan`, contextInfo: {mentionedJid: [roof.ditantang, roof.penantang]}}, {quoted: anu})
}
delete databasesuit[roof.id]
return !0
}, roof.timeout)
} else if (body.toLowerCase() === 'n') {
await conn.sendMessage(m.chat, {text: `@${roof.ditantang.split('@')[0]} menolak suit, suit dibatalkan`, contextInfo: {mentionedJid: [roof.ditantang]}}, {quoted: m})
delete databasesuit[roof.id]
return !0
}
}
let jwb = m.sender == roof.penantang
let jwb2 = m.sender == roof.ditantang
let g = /gunting/i
let b = /batu/i
let k = /kertas/i
let reg = /^(gunting|batu|kertas)/i
if (jwb && reg.test(budy) && !roof.pilih && !isGroup) {
roof.pilih = reg.exec(budy.toLowerCase())[0]
roof.text = budy
await conn.sendMessage(m.chat, {text: `Kamu telah memilih *${budy}* ${!roof.pilih2 ? `\n\nMenunggu lawan memilih` : ''}`}, {quoted: m})
if (!roof.pilih2) await conn.sendMessage(roof.ditantang, {text: 'Lawan sudah memilih\nSekarang giliran kamu'})
}
if (jwb2 && reg.test(budy) && !roof.pilih2 && !isGroup) {
roof.pilih2 = reg.exec(budy.toLowerCase())[0]
roof.text2 = budy
await conn.sendMessage(m.chat, {text: `Kamu telah memilih *${budy}* ${!roof.pilih ? '\n\nMenunggu lawan memilih' : ''}`}, {quoted: m})
if (!roof.pilih) await conn.sendMessage(roof.penantang, {text: 'Lawan sudah memilih\nSekarang giliran kamu'})
}
let stage = roof.pilih
let stage2 = roof.pilih2
if (roof.pilih && roof.pilih2) {
clearTimeout(roof.waktu_milih)
if (b.test(stage) && g.test(stage2)) win = roof.penantang
else if (b.test(stage) && k.test(stage2)) win = roof.ditantang
else if (g.test(stage) && k.test(stage2)) win = roof.penantang
else if (g.test(stage) && b.test(stage2)) win = roof.ditantang
else if (k.test(stage) && b.test(stage2)) win = roof.penantang
else if (k.test(stage) && g.test(stage2)) win = roof.ditantang
else if (stage == stage2) tie = true
let teks = `*🎮 GAME SUIT 🎮*\n\n${tie ? '*HASIL SERI*\n\n' : ''}@${roof.penantang.split('@')[0]} (${roof.text}) ${tie ? '' : roof.penantang == win ? ' Menang' : ' Kalah'}\n@${roof.ditantang.split('@')[0]} (${roof.text2}) ${tie ? '' : roof.ditantang == win ? ' Menang' : ' Kalah'}${tie ? '' : '\n\nHadiah : *$' + roof.hadiah + '* balance'}`
await conn.sendMessage(roof.asal, {text: teks, contextInfo: {mentionedJid: [roof.ditantang, roof.penantang]}}, {quoted: roof.chat})
if (roof.penantang == win) {
global.db.data.users[roof.penantang].balance += roof.hadiah
} else if (roof.ditantang == win) {
global.db.data.users[roof.ditantang].balance += roof.hadiah
}
delete databasesuit[roof.id]
}
}
} catch (e) {
return m.reply(e)
}


try {
let id = m.chat;
let timeout = 180000;
let hadiah = randomNumber(10000, 20000);
let users = global.db.data.users[m.sender];
let budy = typeof m.body == 'string' ? m.body : false;
conn.bomb = conn.bomb ? conn.bomb : {};

if (conn.bomb[id] && !isNaN(body) && !isCmd) {
let json = conn.bomb[id][1].find(v => v.position == body);
if (!json) return
if (json.emot == '💥') {
json.state = true;
let bomb = conn.bomb[id][1];
let teks = `*DUARRRRRR 💥*\n\n`;
teks += bomb.slice(0, 3).map(v => v.state ? v.emot : v.number).join('') + '\n';
teks += bomb.slice(3, 6).map(v => v.state ? v.emot : v.number).join('') + '\n';
teks += bomb.slice(6).map(v => v.state ? v.emot : v.number).join('') + '\n\n';
teks += `@${m.sender.split('@')[0]} membuka kotak yang berisi *Bom* Game di hentikan!`
conn.sendMessage(m.chat, {text: teks, contextInfo: {mentionedJid: [m.sender], externalAdReply: {thumbnailUrl: "https://telegra.ph/file/da5e5612ccead39af2e93.jpg", title: " 🎮  𝗚 𝗔 𝗠 𝗘 - 𝗧 𝗘 𝗕 𝗔 𝗞 - 𝗕 𝗢 𝗢 𝗠  🎮", body: null, renderLargerThumbnail: true, sourceUrl: global.linkgc, mediaType: 1}}}, {quoted: m}).then(() => {
clearTimeout(conn.bomb[id][2]);
delete conn.bomb[id];
});
} else if (json.state) {
return conn.sendMessage(m.chat, { text: `Kotak ${json.number} sudah di buka silahkan pilih kotak yang lain!` }, { quoted: m })
} else {
json.state = true;
let changes = conn.bomb[id][1];
let open = changes.filter(v => v.state && v.emot != '💥').length;

if (open >= 8) {
let teks = `*🎮 GAME TEBAK BOM 🎮*\n\nKirim angka *1* - *9* untuk membuka *9* kotak nomor di bawah ini :\n\n`;
teks += changes.slice(0, 3).map(v => v.state ? v.emot : v.number).join('') + '\n';
teks += changes.slice(3, 6).map(v => v.state ? v.emot : v.number).join('') + '\n';
teks += changes.slice(6).map(v => v.state ? v.emot : v.number).join('') + '\n\n';
teks += `*Permainan selesai!* kotak berisi bom tidak terbuka\n*+ $${toRupiah(hadiah)} balance* ke @${m.sender.split('@')[0]}`;

conn.sendMessage(m.chat, {text: teks, contextInfo: {mentionedJid: [m.sender]}}, {quoted: m}).then(() => {
users.balance += hadiah;
clearTimeout(conn.bomb[id][2]);
delete conn.bomb[id];
});
} else {
let teks = `*🎮 GAME TEBAK BOM 🎮*\n\nKirim angka *1* - *9* untuk membuka *9* kotak nomor di bawah ini :\n\n`;
teks += changes.slice(0, 3).map(v => v.state ? v.emot : v.number).join('') + '\n';
teks += changes.slice(3, 6).map(v => v.state ? v.emot : v.number).join('') + '\n';
teks += changes.slice(6).map(v => v.state ? v.emot : v.number).join('') + '\n\n';
teks += `Waktu : *${((timeout / 1000) / 60)} menit*\n`;
teks += `Kotak berisi bom tidak terbuka\n*+ $${toRupiah(hadiah)} balance* ke @${m.sender.split('@')[0]}`;

conn.sendMessage(m.chat, {text: teks, contextInfo: {mentionedJid: [m.sender]}}, {quoted: m}).then(() => {
users.balance += hadiah;
});
}
}
}
} catch (e) {
return conn.sendMessage(m.chat, { text: e.toString() }, { quoted: m })
}

switch(command) {
//================== [ MENU ] ==================//
case 'help':
case 'menulist':
case 'listmenu':
case 'menu': {
if (!db.data.users[m.sender].registered) return m.reply(mess.regis)
let { upload, download } = await checkBandwidth()
let old = performance.now()
let tekss = `🍟 Hi @${m.sender.split("@")[0]}
 Welcome to Dashboard Bot !

*–  I N T R O  - D U C T I O N*

 my name is ${global.botname}
 your virtual assistant *( WhatsApp bot )*, who will help you in many ways on WhatsApp.

 –  *I N F O - B O T*

┌  ◦  Upload : ${upload}
│  ◦  Download : ${download}
│  ◦  Total Fitur : ${totalFitur()}
│  ◦  Runtime : ${runtime(process.uptime())}
│  ◦  Respons Speed : ${(performance.now() - old).toFixed(5)} ms
└  ◦  Database User  : ${Object.keys(db.data.users).length} User

*– I N F O - U S E R*

┌  ◦  Nomor : @${m.sender.split("@")[0]}
│  ◦  Nama : ${pushname}
│  ◦  Status : ${isCreator ? 'Owner' : 'User'}
│  ◦  User : ${isPremium ? 'Premium' : 'Free'}
│  ◦  Limit : ${limitnya}
└  ◦  Balance : $${toRupiah(balancenya)}

If you find a bug in this bot, please contact the bot owner.

*– L I S T - M E N U*

    ◦ ${prefix}allmenu
    ◦ ${prefix}ownermenu
    ◦ ${prefix}mainmenu
    ◦ ${prefix}groupmenu
    ◦ ${prefix}gamemenu
    ◦ ${prefix}rpgmenu
    ◦ ${prefix}animemenu
    ◦ ${prefix}searchmenu
    ◦ ${prefix}downloadmenu
    ◦ ${prefix}convertmenu
    ◦ ${prefix}toolsmenu
    ◦ ${prefix}panelmenu
    ◦ ${prefix}domainmenu
    ◦ ${prefix}storemenu
    ◦ ${prefix}aimenu`
conn.sendMessage(m.chat, { text: tekss, contextInfo: { mentionedJid: [m.sender], externalAdReply: { thumbnailUrl: global.thumbnail, title: `© Copyright ${ownername}`, body: null, sourceUrl: global.linkgc, renderLargerThumbnail: true, mediaType: 1}}}, { quoted: m })
}
break
case 'menuall':
case 'allmenu': {
if (!db.data.users[m.sender].registered) return m.reply(mess.regis)
let { upload, download } = await checkBandwidth()
let old = performance.now()
let tekss = `🍟 Hi @${m.sender.split("@")[0]}
 Welcome to Dashboard Bot !

*–  I N T R O  - D U C T I O N*

 my name is ${global.botname}
 your virtual assistant *( WhatsApp bot )*, who will help you in many ways on WhatsApp.

 –  *I N F O - B O T*

┌  ◦  Upload : ${upload}
│  ◦  Download : ${download}
│  ◦  Total Fitur : ${totalFitur()}
│  ◦  Runtime : ${runtime(process.uptime())}
│  ◦  Respons Speed : ${(performance.now() - old).toFixed(5)} ms
└  ◦  Database User  : ${Object.keys(db.data.users).length} User

*– I N F O - U S E R*

┌  ◦  Nomor : @${m.sender.split("@")[0]}
│  ◦  Nama : ${pushname}
│  ◦  Status : ${isCreator ? 'Owner' : 'User'}
│  ◦  User : ${isPremium ? 'Premium' : 'Free'}
│  ◦  Limit : ${limitnya}
└  ◦  Balance : $${toRupiah(balancenya)}

If you find a bug in this bot, please contact the bot owner.

*– 乂 M E N U - O W N E R*
                    
    ◦ ${prefix}addprem
    ◦ ${prefix}delprem
    ◦ ${prefix}listprem
    ◦ ${prefix}addcmderror
    ◦ ${prefix}delcmderror
    ◦ ${prefix}listcmderror
    ◦ ${prefix}addcase
    ◦ ${prefix}delcase
    ◦ ${prefix}listcase
    ◦ ${prefix}getcase
    ◦ ${prefix}banned
    ◦ ${prefix}unban
    ◦ ${prefix}listbanned
    ◦ ${prefix}block
    ◦ ${prefix}unblock
    ◦ ${prefix}addlimit
    ◦ ${prefix}addbalance
    ◦ ${prefix}public
    ◦ ${prefix}self
    ◦ ${prefix}joingc
    ◦ ${prefix}leavegc
    ◦ ${prefix}backupsc
    ◦ ${prefix}backupdb
    ◦ ${prefix}getsesi
    ◦ ${prefix}delsesi
    ◦ ${prefix}setppbot
    ◦ ${prefix}setppbotpanjang
    ◦ ${prefix}delppbot
    ◦ ${prefix}setbotname
    ◦ ${prefix}setbotbio
    ◦ ${prefix}listsampah
    ◦ ${prefix}delsampah
    ◦ ${prefix}bcgc
    ◦ ${prefix}setthumbnail
    ◦ ${prefix}delete
    ◦ ${prefix}listpc
    ◦ ${prefix}listgc


*– 乂 M E N U - M A I N*

    ◦ ${prefix}tqto
    ◦ ${prefix}owner
    ◦ ${prefix}script
    ◦ ${prefix}runtime
    ◦ ${prefix}totalfitur 
    ◦ ${prefix}ping
    ◦ ${prefix}daftar
    ◦ ${prefix}ceksn
    ◦ ${prefix}unreg
    ◦ ${prefix}afk


*– 乂 M E N U - G R O U P*

    ◦ ${prefix}add
    ◦ ${prefix}kick
    ◦ ${prefix}promote
    ◦ ${prefix}demote
    ◦ ${prefix}setnamagc
    ◦ ${prefix}setdeskgc
    ◦ ${prefix}editinfogc
    ◦ ${prefix}resetlinkgc
    ◦ ${prefix}hidetag
    ◦ ${prefix}enablegc
    ◦ ${prefix}disablegc
    ◦ ${prefix}opentime
    ◦ ${prefix}closetime 


*– 乂 M E N U - G A M E*

    ◦ ${prefix}tictactoe
    ◦ ${prefix}delttt
    ◦ ${prefix}suit
    ◦ ${prefix}tebakbomb
    ◦ ${prefix}casino
    ◦ ${prefix}bonanza
    ◦ ${prefix}slot


*– 乂 M E N U - R P G*

    ◦ ${prefix}inventory
    ◦ ${prefix}topglobal
    ◦ ${prefix}buylimit
    ◦ ${prefix}belilimit
    ◦ ${prefix}tflimit
    ◦ ${prefix}tfbalance


*– 乂 M E N U - A N I M E*

    ◦ ${prefix}animesearch
    ◦ ${prefix}animedetail


*– 乂 M E N U - S E A R C H*

    ◦ ${prefix}play
    ◦ ${prefix}yts
    ◦ ${prefix}google
    ◦ ${prefix}gimage
    ◦ ${prefix}pinterest
    ◦ ${prefix}ttsearch
    ◦ ${prefix}chord
    ◦ ${prefix}lirik
    ◦ ${prefix}npmjs
    ◦ ${prefix}stickersearch


*– 乂 M E N U - D O W N L O A D*

    ◦ ${prefix}ytmp3
    ◦ ${prefix}ytmp4
    ◦ ${prefix}tiktok
    ◦ ${prefix}tiktokmp3
    ◦ ${prefix}tiktokmp4
    ◦ ${prefix}tiktokslide
    ◦ ${prefix}videy
    ◦ ${prefix}capcut
    ◦ ${prefix}mediafire
    ◦ ${prefix}instagram
    ◦ ${prefix}facebook
    ◦ ${prefix}gitclone 


*– 乂 M E N U - C O N V E R T*

    ◦ ${prefix}sticker
    ◦ ${prefix}swm
    ◦ ${prefix}cls
    ◦ ${prefix}smeme
    ◦ ${prefix}qc
    ◦ ${prefix}qcimg
    ◦ ${prefix}attp
    ◦ ${prefix}ttp
    ◦ ${prefix}tourl
    ◦ ${prefix}toimg
    ◦ ${prefix}toptv
    ◦ ${prefix}tovid
    ◦ ${prefix}togif
    ◦ ${prefix}toaudio
    ◦ ${prefix}tovn
    ◦ ${prefix}toaksara
    ◦ ${prefix}tolatin


*– 乂 M E N U - T O O L S*

    ◦ ${prefix}cekcuaca
    ◦ ${prefix}jarak
    ◦ ${prefix}translate
    ◦ ${prefix}remini
    ◦ ${prefix}hdvid
    ◦ ${prefix}tinyurl
    ◦ ${prefix}toanime
    ◦ ${prefix}tozombie
    ◦ ${prefix}readmore
    ◦ ${prefix}getq
    ◦ ${prefix}cekprovider
    ◦ ${prefix}resolution
    ◦ ${prefix}tohtml
    ◦ ${prefix}sshp
    ◦ ${prefix}sspc
    ◦ ${prefix}sstab


*– 乂 M E N U - P A N E L*

    ◦ ${prefix}addpanel
    ◦ ${prefix}delpanel
    ◦ ${prefix}listpanel
    ◦ ${prefix}addadmin
    ◦ ${prefix}deladmin
    ◦ ${prefix}listadmin


*– 乂 M E N U - D O M A I N*

    ◦ ${prefix}listdomain
    ◦ ${prefix}listsubdomain
    ◦ ${prefix}subfinder


*– 乂 M E N U - S T O R E*

    ◦ ${prefix}done
    ◦ ${prefix}proses
    ◦ ${prefix}tunda
    ◦ ${prefix}batal
    ◦ ${prefix}kalkulator
    ◦ ${prefix}buyprem
    ◦ ${prefix}buysewa


*– 乂 M E N U - A I*

    ◦ ${prefix}ai
    ◦ ${prefix}bard
    ◦ ${prefix}bing
    ◦ ${prefix}turbo
    ◦ ${prefix}sindy
    ◦ ${prefix}alicia
    ◦ ${prefix}siska
    ◦ ${prefix}blackbox`
conn.sendMessage(m.chat, { text: tekss, contextInfo: { mentionedJid: [m.sender], externalAdReply: { thumbnailUrl: global.thumbnail, title: `© Copyright ${ownername}`, body: null, sourceUrl: global.linkgc, renderLargerThumbnail: true, mediaType: 1}}}, { quoted: m })
}
break
case 'menuowner':
case 'ownermenu': {
if (!db.data.users[m.sender].registered) return m.reply(mess.regis)
let { upload, download } = await checkBandwidth()
let old = performance.now()
let tekss = `🍟 Hi @${m.sender.split("@")[0]}
 Welcome to Dashboard Bot !

*–  I N T R O  - D U C T I O N*

 my name is ${global.botname}
 your virtual assistant *( WhatsApp bot )*, who will help you in many ways on WhatsApp.

 –  *I N F O - B O T*

┌  ◦  Upload : ${upload}
│  ◦  Download : ${download}
│  ◦  Total Fitur : ${totalFitur()}
│  ◦  Runtime : ${runtime(process.uptime())}
│  ◦  Respons Speed : ${(performance.now() - old).toFixed(5)} ms
└  ◦  Database User  : ${Object.keys(db.data.users).length} User

*– I N F O - U S E R*

┌  ◦  Nomor : @${m.sender.split("@")[0]}
│  ◦  Nama : ${pushname}
│  ◦  Status : ${isCreator ? 'Owner' : 'User'}
│  ◦  User : ${isPremium ? 'Premium' : 'Free'}
│  ◦  Limit : ${limitnya}
└  ◦  Balance : $${toRupiah(balancenya)}

If you find a bug in this bot, please contact the bot owner.

*– 乂 M E N U - O W N E R*
                    
    ◦ ${prefix}addprem
    ◦ ${prefix}delprem
    ◦ ${prefix}listprem
    ◦ ${prefix}addcmderror
    ◦ ${prefix}delcmderror
    ◦ ${prefix}listcmderror
    ◦ ${prefix}addcase
    ◦ ${prefix}delcase
    ◦ ${prefix}listcase
    ◦ ${prefix}getcase
    ◦ ${prefix}banned
    ◦ ${prefix}unban
    ◦ ${prefix}listbanned
    ◦ ${prefix}block
    ◦ ${prefix}unblock
    ◦ ${prefix}addlimit
    ◦ ${prefix}addbalance
    ◦ ${prefix}public
    ◦ ${prefix}self
    ◦ ${prefix}joingc
    ◦ ${prefix}leavegc
    ◦ ${prefix}backupsc
    ◦ ${prefix}backupdb
    ◦ ${prefix}getsesi
    ◦ ${prefix}delsesi
    ◦ ${prefix}setppbot
    ◦ ${prefix}setppbotpanjang
    ◦ ${prefix}delppbot
    ◦ ${prefix}setbotname
    ◦ ${prefix}setbotbio
    ◦ ${prefix}listsampah
    ◦ ${prefix}delsampah
    ◦ ${prefix}bcgc
    ◦ ${prefix}setthumbnail
    ◦ ${prefix}delete
    ◦ ${prefix}listpc
    ◦ ${prefix}listgc`
conn.sendMessage(m.chat, { text: tekss, contextInfo: { mentionedJid: [m.sender], externalAdReply: { thumbnailUrl: global.thumbnail, title: `© Copyright ${ownername}`, body: null, sourceUrl: global.linkgc, renderLargerThumbnail: true, mediaType: 1}}}, { quoted: m })
}
break
case 'menumain':
case 'mainmenu': {
if (!db.data.users[m.sender].registered) return m.reply(mess.regis)
let { upload, download } = await checkBandwidth()
let old = performance.now()
let tekss = `🍟 Hi @${m.sender.split("@")[0]}
 Welcome to Dashboard Bot !

*–  I N T R O  - D U C T I O N*

 my name is ${global.botname}
 your virtual assistant *( WhatsApp bot )*, who will help you in many ways on WhatsApp.

 –  *I N F O - B O T*

┌  ◦  Upload : ${upload}
│  ◦  Download : ${download}
│  ◦  Total Fitur : ${totalFitur()}
│  ◦  Runtime : ${runtime(process.uptime())}
│  ◦  Respons Speed : ${(performance.now() - old).toFixed(5)} ms
└  ◦  Database User  : ${Object.keys(db.data.users).length} User

*– I N F O - U S E R*

┌  ◦  Nomor : @${m.sender.split("@")[0]}
│  ◦  Nama : ${pushname}
│  ◦  Status : ${isCreator ? 'Owner' : 'User'}
│  ◦  User : ${isPremium ? 'Premium' : 'Free'}
│  ◦  Limit : ${limitnya}
└  ◦  Balance : $${toRupiah(balancenya)}

If you find a bug in this bot, please contact the bot owner.

*– 乂 M E N U - M A I N*

    ◦ ${prefix}tqto
    ◦ ${prefix}owner
    ◦ ${prefix}script
    ◦ ${prefix}runtime
    ◦ ${prefix}totalfitur 
    ◦ ${prefix}ping
    ◦ ${prefix}daftar
    ◦ ${prefix}ceksn
    ◦ ${prefix}unreg
    ◦ ${prefix}afk`
conn.sendMessage(m.chat, { text: tekss, contextInfo: { mentionedJid: [m.sender], externalAdReply: { thumbnailUrl: global.thumbnail, title: `© Copyright ${ownername}`, body: null, sourceUrl: global.linkgc, renderLargerThumbnail: true, mediaType: 1}}}, { quoted: m })
}
break
case 'menugroup':
case 'groupmenu': {
if (!db.data.users[m.sender].registered) return m.reply(mess.regis)
let { upload, download } = await checkBandwidth()
let old = performance.now()
let tekss = `🍟 Hi @${m.sender.split("@")[0]}
 Welcome to Dashboard Bot !

*–  I N T R O  - D U C T I O N*

 my name is ${global.botname}
 your virtual assistant *( WhatsApp bot )*, who will help you in many ways on WhatsApp.

 –  *I N F O - B O T*

┌  ◦  Upload : ${upload}
│  ◦  Download : ${download}
│  ◦  Total Fitur : ${totalFitur()}
│  ◦  Runtime : ${runtime(process.uptime())}
│  ◦  Respons Speed : ${(performance.now() - old).toFixed(5)} ms
└  ◦  Database User  : ${Object.keys(db.data.users).length} User

*– I N F O - U S E R*

┌  ◦  Nomor : @${m.sender.split("@")[0]}
│  ◦  Nama : ${pushname}
│  ◦  Status : ${isCreator ? 'Owner' : 'User'}
│  ◦  User : ${isPremium ? 'Premium' : 'Free'}
│  ◦  Limit : ${limitnya}
└  ◦  Balance : $${toRupiah(balancenya)}

If you find a bug in this bot, please contact the bot owner.

*– 乂 M E N U - G R O U P*

    ◦ ${prefix}add
    ◦ ${prefix}kick
    ◦ ${prefix}promote
    ◦ ${prefix}demote
    ◦ ${prefix}setnamagc
    ◦ ${prefix}setdeskgc
    ◦ ${prefix}editinfogc
    ◦ ${prefix}resetlinkgc
    ◦ ${prefix}hidetag
    ◦ ${prefix}enablegc
    ◦ ${prefix}disablegc
    ◦ ${prefix}opentime
    ◦ ${prefix}closetime`
conn.sendMessage(m.chat, { text: tekss, contextInfo: { mentionedJid: [m.sender], externalAdReply: { thumbnailUrl: global.thumbnail, title: `© Copyright ${ownername}`, body: null, sourceUrl: global.linkgc, renderLargerThumbnail: true, mediaType: 1}}}, { quoted: m })
}
break
case 'menugame':
case 'gamemenu': {
if (!db.data.users[m.sender].registered) return m.reply(mess.regis)
let { upload, download } = await checkBandwidth()
let old = performance.now()
let tekss = `🍟 Hi @${m.sender.split("@")[0]}
 Welcome to Dashboard Bot !

*–  I N T R O  - D U C T I O N*

 my name is ${global.botname}
 your virtual assistant *( WhatsApp bot )*, who will help you in many ways on WhatsApp.

 –  *I N F O - B O T*

┌  ◦  Upload : ${upload}
│  ◦  Download : ${download}
│  ◦  Total Fitur : ${totalFitur()}
│  ◦  Runtime : ${runtime(process.uptime())}
│  ◦  Respons Speed : ${(performance.now() - old).toFixed(5)} ms
└  ◦  Database User  : ${Object.keys(db.data.users).length} User

*– I N F O - U S E R*

┌  ◦  Nomor : @${m.sender.split("@")[0]}
│  ◦  Nama : ${pushname}
│  ◦  Status : ${isCreator ? 'Owner' : 'User'}
│  ◦  User : ${isPremium ? 'Premium' : 'Free'}
│  ◦  Limit : ${limitnya}
└  ◦  Balance : $${toRupiah(balancenya)}

If you find a bug in this bot, please contact the bot owner.

*– 乂 M E N U - G A M E*

    ◦ ${prefix}tictactoe
    ◦ ${prefix}delttt
    ◦ ${prefix}suit
    ◦ ${prefix}tebakbomb
    ◦ ${prefix}casino
    ◦ ${prefix}bonanza
    ◦ ${prefix}slot`
conn.sendMessage(m.chat, { text: tekss, contextInfo: { mentionedJid: [m.sender], externalAdReply: { thumbnailUrl: global.thumbnail, title: `© Copyright ${ownername}`, body: null, sourceUrl: global.linkgc, renderLargerThumbnail: true, mediaType: 1}}}, { quoted: m })
}
break
case 'menurpg':
case 'rpgmenu': {
if (!db.data.users[m.sender].registered) return m.reply(mess.regis)
let { upload, download } = await checkBandwidth()
let old = performance.now()
let tekss = `🍟 Hi @${m.sender.split("@")[0]}
 Welcome to Dashboard Bot !

*–  I N T R O  - D U C T I O N*

 my name is ${global.botname}
 your virtual assistant *( WhatsApp bot )*, who will help you in many ways on WhatsApp.

 –  *I N F O - B O T*

┌  ◦  Upload : ${upload}
│  ◦  Download : ${download}
│  ◦  Total Fitur : ${totalFitur()}
│  ◦  Runtime : ${runtime(process.uptime())}
│  ◦  Respons Speed : ${(performance.now() - old).toFixed(5)} ms
└  ◦  Database User  : ${Object.keys(db.data.users).length} User

*– I N F O - U S E R*

┌  ◦  Nomor : @${m.sender.split("@")[0]}
│  ◦  Nama : ${pushname}
│  ◦  Status : ${isCreator ? 'Owner' : 'User'}
│  ◦  User : ${isPremium ? 'Premium' : 'Free'}
│  ◦  Limit : ${limitnya}
└  ◦  Balance : $${toRupiah(balancenya)}

If you find a bug in this bot, please contact the bot owner.

*– 乂 M E N U - R P G*

    ◦ ${prefix}inventory
    ◦ ${prefix}topglobal
    ◦ ${prefix}buylimit
    ◦ ${prefix}belilimit
    ◦ ${prefix}tflimit
    ◦ ${prefix}tfbalance`
conn.sendMessage(m.chat, { text: tekss, contextInfo: { mentionedJid: [m.sender], externalAdReply: { thumbnailUrl: global.thumbnail, title: `© Copyright ${ownername}`, body: null, sourceUrl: global.linkgc, renderLargerThumbnail: true, mediaType: 1}}}, { quoted: m })
}
break
case 'menuanime':
case 'animemenu': {
if (!db.data.users[m.sender].registered) return m.reply(mess.regis)
let { upload, download } = await checkBandwidth()
let old = performance.now()
let tekss = `🍟 Hi @${m.sender.split("@")[0]}
 Welcome to Dashboard Bot !

*–  I N T R O  - D U C T I O N*

 my name is ${global.botname}
 your virtual assistant *( WhatsApp bot )*, who will help you in many ways on WhatsApp.

 –  *I N F O - B O T*

┌  ◦  Upload : ${upload}
│  ◦  Download : ${download}
│  ◦  Total Fitur : ${totalFitur()}
│  ◦  Runtime : ${runtime(process.uptime())}
│  ◦  Respons Speed : ${(performance.now() - old).toFixed(5)} ms
└  ◦  Database User  : ${Object.keys(db.data.users).length} User

*– I N F O - U S E R*

┌  ◦  Nomor : @${m.sender.split("@")[0]}
│  ◦  Nama : ${pushname}
│  ◦  Status : ${isCreator ? 'Owner' : 'User'}
│  ◦  User : ${isPremium ? 'Premium' : 'Free'}
│  ◦  Limit : ${limitnya}
└  ◦  Balance : $${toRupiah(balancenya)}

If you find a bug in this bot, please contact the bot owner.

*– 乂 M E N U - A N I M E*

    ◦ ${prefix}animesearch
    ◦ ${prefix}animedetail`
conn.sendMessage(m.chat, { text: tekss, contextInfo: { mentionedJid: [m.sender], externalAdReply: { thumbnailUrl: global.thumbnail, title: `© Copyright ${ownername}`, body: null, sourceUrl: global.linkgc, renderLargerThumbnail: true, mediaType: 1}}}, { quoted: m })
}
break
case 'menusearch':
case 'searchmenu': {
if (!db.data.users[m.sender].registered) return m.reply(mess.regis)
let { upload, download } = await checkBandwidth()
let old = performance.now()
let tekss = `🍟 Hi @${m.sender.split("@")[0]}
 Welcome to Dashboard Bot !

*–  I N T R O  - D U C T I O N*

 my name is ${global.botname}
 your virtual assistant *( WhatsApp bot )*, who will help you in many ways on WhatsApp.

 –  *I N F O - B O T*

┌  ◦  Upload : ${upload}
│  ◦  Download : ${download}
│  ◦  Total Fitur : ${totalFitur()}
│  ◦  Runtime : ${runtime(process.uptime())}
│  ◦  Respons Speed : ${(performance.now() - old).toFixed(5)} ms
└  ◦  Database User  : ${Object.keys(db.data.users).length} User

*– I N F O - U S E R*

┌  ◦  Nomor : @${m.sender.split("@")[0]}
│  ◦  Nama : ${pushname}
│  ◦  Status : ${isCreator ? 'Owner' : 'User'}
│  ◦  User : ${isPremium ? 'Premium' : 'Free'}
│  ◦  Limit : ${limitnya}
└  ◦  Balance : $${toRupiah(balancenya)}

If you find a bug in this bot, please contact the bot owner.

*– 乂 M E N U - S E A R C H*

    ◦ ${prefix}play
    ◦ ${prefix}yts
    ◦ ${prefix}google
    ◦ ${prefix}gimage
    ◦ ${prefix}pinterest
    ◦ ${prefix}ttsearch
    ◦ ${prefix}chord
    ◦ ${prefix}lirik
    ◦ ${prefix}npmjs
    ◦ ${prefix}stickersearch`
conn.sendMessage(m.chat, { text: tekss, contextInfo: { mentionedJid: [m.sender], externalAdReply: { thumbnailUrl: global.thumbnail, title: `© Copyright ${ownername}`, body: null, sourceUrl: global.linkgc, renderLargerThumbnail: true, mediaType: 1}}}, { quoted: m })
}
break
case 'menudownload':
case 'downloadmenu': {
if (!db.data.users[m.sender].registered) return m.reply(mess.regis)
let { upload, download } = await checkBandwidth()
let old = performance.now()
let tekss = `🍟 Hi @${m.sender.split("@")[0]}
 Welcome to Dashboard Bot !

*–  I N T R O  - D U C T I O N*

 my name is ${global.botname}
 your virtual assistant *( WhatsApp bot )*, who will help you in many ways on WhatsApp.

 –  *I N F O - B O T*

┌  ◦  Upload : ${upload}
│  ◦  Download : ${download}
│  ◦  Total Fitur : ${totalFitur()}
│  ◦  Runtime : ${runtime(process.uptime())}
│  ◦  Respons Speed : ${(performance.now() - old).toFixed(5)} ms
└  ◦  Database User  : ${Object.keys(db.data.users).length} User

*– I N F O - U S E R*

┌  ◦  Nomor : @${m.sender.split("@")[0]}
│  ◦  Nama : ${pushname}
│  ◦  Status : ${isCreator ? 'Owner' : 'User'}
│  ◦  User : ${isPremium ? 'Premium' : 'Free'}
│  ◦  Limit : ${limitnya}
└  ◦  Balance : $${toRupiah(balancenya)}

If you find a bug in this bot, please contact the bot owner.

*– 乂 M E N U - D O W N L O A D*

    ◦ ${prefix}ytmp3
    ◦ ${prefix}ytmp4
    ◦ ${prefix}tiktok
    ◦ ${prefix}tiktokmp3
    ◦ ${prefix}tiktokmp4
    ◦ ${prefix}tiktokslide
    ◦ ${prefix}videy
    ◦ ${prefix}capcut
    ◦ ${prefix}mediafire
    ◦ ${prefix}instagram
    ◦ ${prefix}facebook
    ◦ ${prefix}gitclone`
conn.sendMessage(m.chat, { text: tekss, contextInfo: { mentionedJid: [m.sender], externalAdReply: { thumbnailUrl: global.thumbnail, title: `© Copyright ${ownername}`, body: null, sourceUrl: global.linkgc, renderLargerThumbnail: true, mediaType: 1}}}, { quoted: m })
}
break
case 'menuconvert':
case 'convertmenu': {
if (!db.data.users[m.sender].registered) return m.reply(mess.regis)
let { upload, download } = await checkBandwidth()
let old = performance.now()
let tekss = `🍟 Hi @${m.sender.split("@")[0]}
 Welcome to Dashboard Bot !

*–  I N T R O  - D U C T I O N*

 my name is ${global.botname}
 your virtual assistant *( WhatsApp bot )*, who will help you in many ways on WhatsApp.

 –  *I N F O - B O T*

┌  ◦  Upload : ${upload}
│  ◦  Download : ${download}
│  ◦  Total Fitur : ${totalFitur()}
│  ◦  Runtime : ${runtime(process.uptime())}
│  ◦  Respons Speed : ${(performance.now() - old).toFixed(5)} ms
└  ◦  Database User  : ${Object.keys(db.data.users).length} User

*– I N F O - U S E R*

┌  ◦  Nomor : @${m.sender.split("@")[0]}
│  ◦  Nama : ${pushname}
│  ◦  Status : ${isCreator ? 'Owner' : 'User'}
│  ◦  User : ${isPremium ? 'Premium' : 'Free'}
│  ◦  Limit : ${limitnya}
└  ◦  Balance : $${toRupiah(balancenya)}

If you find a bug in this bot, please contact the bot owner.

*– 乂 M E N U - C O N V E R T*

    ◦ ${prefix}sticker
    ◦ ${prefix}swm
    ◦ ${prefix}cls
    ◦ ${prefix}smeme
    ◦ ${prefix}qc
    ◦ ${prefix}qcimg
    ◦ ${prefix}attp
    ◦ ${prefix}ttp
    ◦ ${prefix}tourl
    ◦ ${prefix}toimg
    ◦ ${prefix}toptv
    ◦ ${prefix}tovid
    ◦ ${prefix}togif
    ◦ ${prefix}toaudio
    ◦ ${prefix}tovn
    ◦ ${prefix}toaksara
    ◦ ${prefix}tolatin`
conn.sendMessage(m.chat, { text: tekss, contextInfo: { mentionedJid: [m.sender], externalAdReply: { thumbnailUrl: global.thumbnail, title: `© Copyright ${ownername}`, body: null, sourceUrl: global.linkgc, renderLargerThumbnail: true, mediaType: 1}}}, { quoted: m })
}
break
case 'menutools':
case 'toolsmenu': {
if (!db.data.users[m.sender].registered) return m.reply(mess.regis)
let { upload, download } = await checkBandwidth()
let old = performance.now()
let tekss = `🍟 Hi @${m.sender.split("@")[0]}
 Welcome to Dashboard Bot !

*–  I N T R O  - D U C T I O N*

 my name is ${global.botname}
 your virtual assistant *( WhatsApp bot )*, who will help you in many ways on WhatsApp.

 –  *I N F O - B O T*

┌  ◦  Upload : ${upload}
│  ◦  Download : ${download}
│  ◦  Total Fitur : ${totalFitur()}
│  ◦  Runtime : ${runtime(process.uptime())}
│  ◦  Respons Speed : ${(performance.now() - old).toFixed(5)} ms
└  ◦  Database User  : ${Object.keys(db.data.users).length} User

*– I N F O - U S E R*

┌  ◦  Nomor : @${m.sender.split("@")[0]}
│  ◦  Nama : ${pushname}
│  ◦  Status : ${isCreator ? 'Owner' : 'User'}
│  ◦  User : ${isPremium ? 'Premium' : 'Free'}
│  ◦  Limit : ${limitnya}
└  ◦  Balance : $${toRupiah(balancenya)}

If you find a bug in this bot, please contact the bot owner.

*– 乂 M E N U - T O O L S*

    ◦ ${prefix}cekcuaca
    ◦ ${prefix}jarak
    ◦ ${prefix}translate
    ◦ ${prefix}remini
    ◦ ${prefix}hdvid
    ◦ ${prefix}tinyurl
    ◦ ${prefix}toanime
    ◦ ${prefix}tozombie
    ◦ ${prefix}readmore
    ◦ ${prefix}getq
    ◦ ${prefix}cekprovider
    ◦ ${prefix}resolution
    ◦ ${prefix}tohtml
    ◦ ${prefix}sshp
    ◦ ${prefix}sspc
    ◦ ${prefix}sstab`
conn.sendMessage(m.chat, { text: tekss, contextInfo: { mentionedJid: [m.sender], externalAdReply: { thumbnailUrl: global.thumbnail, title: `© Copyright ${ownername}`, body: null, sourceUrl: global.linkgc, renderLargerThumbnail: true, mediaType: 1}}}, { quoted: m })
}
break
case 'menupanel':
case 'panelmenu': {
if (!db.data.users[m.sender].registered) return m.reply(mess.regis)
let { upload, download } = await checkBandwidth()
let old = performance.now()
let tekss = `🍟 Hi @${m.sender.split("@")[0]}
 Welcome to Dashboard Bot !

*–  I N T R O  - D U C T I O N*

 my name is ${global.botname}
 your virtual assistant *( WhatsApp bot )*, who will help you in many ways on WhatsApp.

 –  *I N F O - B O T*

┌  ◦  Upload : ${upload}
│  ◦  Download : ${download}
│  ◦  Total Fitur : ${totalFitur()}
│  ◦  Runtime : ${runtime(process.uptime())}
│  ◦  Respons Speed : ${(performance.now() - old).toFixed(5)} ms
└  ◦  Database User  : ${Object.keys(db.data.users).length} User

*– I N F O - U S E R*

┌  ◦  Nomor : @${m.sender.split("@")[0]}
│  ◦  Nama : ${pushname}
│  ◦  Status : ${isCreator ? 'Owner' : 'User'}
│  ◦  User : ${isPremium ? 'Premium' : 'Free'}
│  ◦  Limit : ${limitnya}
└  ◦  Balance : $${toRupiah(balancenya)}

If you find a bug in this bot, please contact the bot owner.

*– 乂 M E N U - P A N E L*

    ◦ ${prefix}addpanel
    ◦ ${prefix}delpanel
    ◦ ${prefix}listpanel
    ◦ ${prefix}addadmin
    ◦ ${prefix}deladmin
    ◦ ${prefix}listadmin`
conn.sendMessage(m.chat, { text: tekss, contextInfo: { mentionedJid: [m.sender], externalAdReply: { thumbnailUrl: global.thumbnail, title: `© Copyright ${ownername}`, body: null, sourceUrl: global.linkgc, renderLargerThumbnail: true, mediaType: 1}}}, { quoted: m })
}
break
case 'menudomain':
case 'domainmenu': {
if (!db.data.users[m.sender].registered) return m.reply(mess.regis)
let { upload, download } = await checkBandwidth()
let old = performance.now()
let tekss = `🍟 Hi @${m.sender.split("@")[0]}
 Welcome to Dashboard Bot !

*–  I N T R O  - D U C T I O N*

 my name is ${global.botname}
 your virtual assistant *( WhatsApp bot )*, who will help you in many ways on WhatsApp.

 –  *I N F O - B O T*

┌  ◦  Upload : ${upload}
│  ◦  Download : ${download}
│  ◦  Total Fitur : ${totalFitur()}
│  ◦  Runtime : ${runtime(process.uptime())}
│  ◦  Respons Speed : ${(performance.now() - old).toFixed(5)} ms
└  ◦  Database User  : ${Object.keys(db.data.users).length} User

*– I N F O - U S E R*

┌  ◦  Nomor : @${m.sender.split("@")[0]}
│  ◦  Nama : ${pushname}
│  ◦  Status : ${isCreator ? 'Owner' : 'User'}
│  ◦  User : ${isPremium ? 'Premium' : 'Free'}
│  ◦  Limit : ${limitnya}
└  ◦  Balance : $${toRupiah(balancenya)}

If you find a bug in this bot, please contact the bot owner.

*– 乂 M E N U - D O M A I N*

    ◦ ${prefix}listdomain
    ◦ ${prefix}listsubdomain
    ◦ ${prefix}subfinder`
conn.sendMessage(m.chat, { text: tekss, contextInfo: { mentionedJid: [m.sender], externalAdReply: { thumbnailUrl: global.thumbnail, title: `© Copyright ${ownername}`, body: null, sourceUrl: global.linkgc, renderLargerThumbnail: true, mediaType: 1}}}, { quoted: m })
}
break
case 'menustore':
case 'storemenu': {
if (!db.data.users[m.sender].registered) return m.reply(mess.regis)
let { upload, download } = await checkBandwidth()
let old = performance.now()
let tekss = `🍟 Hi @${m.sender.split("@")[0]}
 Welcome to Dashboard Bot !

*–  I N T R O  - D U C T I O N*

 my name is ${global.botname}
 your virtual assistant *( WhatsApp bot )*, who will help you in many ways on WhatsApp.

 –  *I N F O - B O T*

┌  ◦  Upload : ${upload}
│  ◦  Download : ${download}
│  ◦  Total Fitur : ${totalFitur()}
│  ◦  Runtime : ${runtime(process.uptime())}
│  ◦  Respons Speed : ${(performance.now() - old).toFixed(5)} ms
└  ◦  Database User  : ${Object.keys(db.data.users).length} User

*– I N F O - U S E R*

┌  ◦  Nomor : @${m.sender.split("@")[0]}
│  ◦  Nama : ${pushname}
│  ◦  Status : ${isCreator ? 'Owner' : 'User'}
│  ◦  User : ${isPremium ? 'Premium' : 'Free'}
│  ◦  Limit : ${limitnya}
└  ◦  Balance : $${toRupiah(balancenya)}

If you find a bug in this bot, please contact the bot owner.

*– 乂 M E N U - S T O R E*

    ◦ ${prefix}done
    ◦ ${prefix}proses
    ◦ ${prefix}tunda
    ◦ ${prefix}batal
    ◦ ${prefix}kalkulator
    ◦ ${prefix}buyprem
    ◦ ${prefix}buysewa`
conn.sendMessage(m.chat, { text: tekss, contextInfo: { mentionedJid: [m.sender], externalAdReply: { thumbnailUrl: global.thumbnail, title: `© Copyright ${ownername}`, body: null, sourceUrl: global.linkgc, renderLargerThumbnail: true, mediaType: 1}}}, { quoted: m })
}
break
case 'menuai':
case 'aimenu': {
if (!db.data.users[m.sender].registered) return m.reply(mess.regis)
let { upload, download } = await checkBandwidth()
let old = performance.now()
let tekss = `🍟 Hi @${m.sender.split("@")[0]}
 Welcome to Dashboard Bot !

*–  I N T R O  - D U C T I O N*

 my name is ${global.botname}
 your virtual assistant *( WhatsApp bot )*, who will help you in many ways on WhatsApp.

 –  *I N F O - B O T*

┌  ◦  Upload : ${upload}
│  ◦  Download : ${download}
│  ◦  Total Fitur : ${totalFitur()}
│  ◦  Runtime : ${runtime(process.uptime())}
│  ◦  Respons Speed : ${(performance.now() - old).toFixed(5)} ms
└  ◦  Database User  : ${Object.keys(db.data.users).length} User

*– I N F O - U S E R*

┌  ◦  Nomor : @${m.sender.split("@")[0]}
│  ◦  Nama : ${pushname}
│  ◦  Status : ${isCreator ? 'Owner' : 'User'}
│  ◦  User : ${isPremium ? 'Premium' : 'Free'}
│  ◦  Limit : ${limitnya}
└  ◦  Balance : $${toRupiah(balancenya)}

If you find a bug in this bot, please contact the bot owner.

*– 乂 M E N U - A I*

    ◦ ${prefix}ai
    ◦ ${prefix}bard
    ◦ ${prefix}bing
    ◦ ${prefix}turbo
    ◦ ${prefix}sindy
    ◦ ${prefix}alicia
    ◦ ${prefix}siska
    ◦ ${prefix}blackbox`
conn.sendMessage(m.chat, { text: tekss, contextInfo: { mentionedJid: [m.sender], externalAdReply: { thumbnailUrl: global.thumbnail, title: `© Copyright ${ownername}`, body: null, sourceUrl: global.linkgc, renderLargerThumbnail: true, mediaType: 1}}}, { quoted: m })
}
break

//================== [ OWNER MENU ] ==================//
case 'addpremium':
case 'addprem': {
if (!isCreator) return m.reply(mess.owner)
let b = text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (args[0] == 'a') {
if (b in db.data.users) {
if (db.data.users[b].premium == true) return m.reply(`User ${args[0]} sudah menjadi *User Premium!*`)
db.data.users[b].limit += 10000
db.data.users[b].balance += 10000000000
db.data.users[b].premium = true
m.reply(`Berhasil update user ${args[1]} ke *User Premium*`) 
} else return m.reply(`User ${args[1]} tidak terdaftar di database bot`)
} else if (args[0] == 'b') {
if (b in db.data.users) {
if (db.data.users[b].premium == true) return m.reply(`User ${args[0]} sudah menjadi *User Premium!*`)
db.data.users[b].limit += 20000
db.data.users[b].balance += 30000000000
db.data.users[b].premium = true
m.reply(`Berhasil update user ${args[1]} ke *User Premium*`) 
} else return m.reply(`User ${args[1]} tidak terdaftar di database bot`)
} else if (args[0] == 'c') {
if (b in db.data.users) {
if (db.data.users[b].premium == true) return m.reply(`User ${args[0]} sudah menjadi *User Premium!*`)
db.data.users[b].limit += 30000
db.data.users[b].balance += 50000000000
db.data.users[b].premium = true
m.reply(`Berhasil update user ${args[1]} ke *User Premium*`) 
} else return m.reply(`User ${args[1]} tidak terdaftar di database bot`)
} else return m.reply(example('namapaket nomornya\n\n*List Paket :*\na | b | c'))
}
break
case 'delpremium':
case 'delprem': {
if (!isCreator) return m.reply(mess.owner)
if (!text) return m.reply(example('nomornya'))
let user = text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (db.data.users[user].premium == false) return m.reply(`User ${args[0]} bukan *User Premium!*`)
if (user in db.data.users) {
db.data.users[user].premium = false
m.reply("Berhasil menghapus *User Premium*")
} else return m.reply(`User ${args[0]} tidak terdaftar di database bot`)
}
break
case 'listprem':
case 'listpremium': {
if (!isCreator) return m.reply(mess.owner)
let user = Object.keys(db.data.users)
let ar = []
let urut = 1
var teks = '\n*乂 LIST USER PREMIUM*\n\n'
user.forEach((e) => {
if (db.data.users[e].premium == true) {
let no = urut++
teks += `${no}. @${e.split("@")[0]}\n`
ar.push(e)
}
})
if (ar.length < 1) {
m.reply("Tidak Ada User Premium")
} else {
conn.sendMessage(m.chat, { text: teks, contextInfo: { mentionedJid: [...ar] }}, { quoted: m })
}}
break
case 'addcmderror':
case 'adderror': {
if (!isCreator) return m.reply(mess.owner)
if (!args[0]) return m.reply(example('namacmd'))
if (args[0] !== args[0].toLowerCase(args[0])) return m.reply("Nama command harus huruf kecil semua!")
if (db.data.settings.error.includes(args[0])) return m.reply(`Command *${args[0]}* sudah ada di dalam daftar *Error*`)
let a = await fs.readFileSync('./message.js').toString()
if (a.includes(`case '${args[0]}'`)) {
m.reply(`Berhasil menambah command *${args[0]}* kedalam daftar *error*`)
db.data.settings.error.push(args[0])
} else {
m.reply(`Command *${args[0]}* tidak di temukan!`)
}}
break
case 'delcmderror':
case 'delerror': {
if (!isCreator) return m.reply(mess.owner)
if (!args[0]) return m.reply(example('namacmd'))
if (args[0] !== args[0].toLowerCase(args[0])) return m.reply("Nama command harus huruf kecil semua!")
if (!db.data.settings.error.includes(args[0])) return m.reply(`Command *${args[0]}* tidak ada di dalam daftar *Error*`)
let index = db.data.settings.error.indexOf(args[0])
db.data.settings.error.splice(index, 1)
m.reply(`Berhasil menghapus command *${args[0]}* dari daftar *Error*`)
}
break
case 'listcmderror':
case 'listerror': {
let teks = `*乂 LIST ALL COMMAND ERROR*\n\nTotal : *${db.data.settings.error.length}*\n\n`
db.data.settings.error.forEach((i) => {
teks += `*◦ ${i}*\n`
})
m.reply(teks)
}
break
case 'addfitur':
case 'addcase': {
if (!isCreator) return m.reply(mess.owner)
if (!text && !text.includes('case')) return m.reply(example('codenya'))
const filePath = './message.js'
const searchString = 'break'
const newString = `break\n${fullargs}\nbreak`
const fileContent = fs.readFileSync(filePath, 'utf8')
const startIndex = fileContent.indexOf(searchString)
if (startIndex !== -1) {
const updatedContent = fileContent.slice(0, startIndex) + newString + fileContent.slice(startIndex + searchString.length)
fs.writeFileSync(filePath, updatedContent, 'utf8')
m.reply('Case berhasil ditambahkan kedalam file message.js!')
}
}
break
case 'delfitur':
case 'delcase': {
if (!isCreator) return m.reply(mess.owner)
if (!text) return m.reply(example('casenya'))
await dellCase('./message.js', text)
m.reply(mess.done)
}
break
case 'listfitur':
case 'listcase': {
if (!isCreator) return m.reply(mess.owner)
m.reply(listCase())
}
break
case 'getfitur':
case 'getcase': {
if (!isCreator) return m.reply(mess.owner)
if (!text) return m.reply(example('casenya'))
try {
let nana = await getCase(text)
m.reply(nana)
} catch (err) {
console.log(err)
m.reply(`Case ${text} tidak di temukan`)
}
}
break
case 'ban':
case 'banneduser':
case 'banned': {
if (!isCreator) return m.reply(mess.owner)
if (m.quoted || text) {
let data = Object.keys(db.data.users)
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (!data.includes(users)) return m.reply("User tidak terdaftar di dalam database bot")
db.data.users[users].banned = true
m.reply(mess.done)
} else return m.reply(example('nomornya'))
}
break
case 'unban':
case 'unbanneduser':
case 'unbanned': {
if (!isCreator) return m.reply(mess.owner)
if (m.quoted || text) {
let data = Object.keys(db.data.users)
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (!data.includes(users)) return m.reply("User tidak terdaftar di dalam database bot")
db.data.users[users].banned = false
m.reply(mess.done)
} else return m.reply(example('nomornya'))
}
break
case 'listban':
case 'listbanned': {
if (!isCreator) return m.reply(mess.owner)
var data = Object.keys(db.data.users)
let teks = ' *乂 LIST BANNED USER*\n\n'
let aray = []
data.map((user) => {
if (db.data.users[user].banned == true) {
aray.push(user)
}})
teks += ` Total : *${aray.length}*\n\n`
for (let i of aray) {
teks += `◦ ${i.split('@')[0]}\n`
}
m.reply(teks)
}
break
case 'block':
case 'blok': {
if (!isCreator) return m.reply(mess.owner)
if (m.quoted || text) {
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await conn.updateBlockStatus(users, 'block').then((res) => m.reply(mess.done)).catch((err) => m.reply(mess.error))
} else return m.reply(example('nomornya'))
}
break
case 'unblock':
case 'unblok': {
if (!isCreator) return m.reply(mess.owner)
if (text || m.quoted) {
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await conn.updateBlockStatus(users, 'unblock').then((res) => m.reply(mess.done)).catch((err) => m.reply(mess.error))
} else return m.reply(example('nomornya'))
}
break
case 'addlimit': {
if (!isCreator) return m.reply(mess.owner)
let user = args[0]+'@s.whatsapp.net'
if (args[0] && args[1]) {
if (isNaN(args[0])) return m.reply('nomornya limitnya')
if (!Object.keys(db.data.users).includes(user)) return m.reply("Nomor target tidak terdaftar di database bot!")
if (isNaN(args[1])) return m.reply('nomornya limitnya')
db.data.users[`${user}`].limit += Number(args[1])
conn.sendMessage(m.chat, { text: `Berhasil menambah *${args[1]}* limit ke ${user.split('@')[0]}` }, { quoted: m })
} else return m.reply(example('nomornya limitnya'))
}
break
case 'addbalance': {
if (!isCreator) return m.reply(mess.owner)
let user = args[0]+'@s.whatsapp.net'
if (args[0] && args[1]) {
if (isNaN(args[0])) return m.reply('nomornya limitnya')
if (!Object.keys(db.data.users).includes(user)) return m.reply("Nomor target tidak terdaftar di database bot!")
if (isNaN(args[1])) return m.reply('nomornya limitnya')
db.data.users[`${user}`].balance += Number(args[1])
conn.sendMessage(m.chat, { text: `Berhasil menambah *${args[1]}* balance ke ${user.split('@')[0]}` }, { quoted: m })
} else return m.reply(example('nomornya limitnya'))
}
break
case 'public': {
if (!isCreator) return m.reply(mess.owner)
conn.public = true
m.reply(mess.done)
}
break
case 'self': {
if (!isCreator) return m.reply(mess.owner)
conn.public = false
m.reply(mess.done)
}
break
case 'joingc':
case 'join': {
if (!isCreator) return m.reply(mess.owner)
if (!text && !m.quoted) return m.reply(example('linknya'))
let teks = m.quoted ? m.quoted.text : text
if (!teks.includes('whatsapp.com')) return m.reply("Link Tautan Tidak Valid!")
let result = teks.split('https://chat.whatsapp.com/')[1]
await conn.groupAcceptInvite(result).then(respon => m.reply("Berhasil Bergabung Ke Dalam Grup ✅")).catch(error => m.reply(error.toString()))
}
break
case 'leavegc':
case 'leave': {
if (!isCreator) return m.reply(mess.owner)
if (text) {
conn.sendMessage(m.chat, { text: "Berhasil keluar group melalui id" }, { quoted: m }).then(() => conn.groupLeave(text))
} else if (m.isGroup) {
conn.sendMessage(m.chat, { text: "Otw boss" }, { quoted: m }).then(() => conn.groupLeave(m.chat))
} else {
return m.reply(example('idgrupnya'))
}}
break
case 'backupscript':
case 'backupsc': {
if (!isCreator) return m.reply(mess.owner)
m.reply(mess.wait)
const ls = (await execSync("ls"))
.toString()
.split("\n")
.filter(
(pe) =>
pe != "node_modules" &&
pe != "session" &&
pe != "package-lock.json" &&
pe != "yarn.lock" &&
pe != ".cache" &&
pe != ".npm"
);
const exec = await execSync(`zip -r New.zip ${ls.join(" ")}`);
await conn.sendMessage(
m.chat,
{
document: await fs.readFileSync("./New.zip"),
mimetype: "application/zip",
fileName: "New.zip",
},
{ quoted: m }
);
await execSync("rm -rf New.zip");
}
break
case 'backupdb':
case 'backupdatabase': {
if (!isCreator) return m.reply(mess.owner)
m.reply(mess.wait)
conn.sendMessage(m.chat, {document: await fs.readFileSync('./database/database.json'), fileName: 'database.json', mimetype: 'application/json'}, {quoted: m})
}
break
case 'getsesi':
case 'ambilsesi': {
if (!isCreator) return m.reply(mess.owner)
m.reply(`Tunggu Sebentar, Sedang mengambil file session mu`)
let sesi = await fs.readFileSync(`./session/creds.json`)
conn.sendMessage(m.chat, { document: sesi, mimetype: 'application/json', fileName: `session.js` }, { quoted: m })
}
break
case 'delsesi':
case 'hapusesi': {
if (!isCreator) return m.reply(mess.owner)
let sessions = 'session'
fs.readdir(sessions, (err, files) => {
if (err) return m.reply("Error terjadi kesalahan!")
for (const file of files) {
if (file !== 'creds.json') {
fs.unlink(path.join(sessions, file), err => {
if (err) return m.reply("Error terjadi kesalahan!")
})
}}
m.reply(`Berhasil Menghapus *${files.length - 1}* sampah file sessions`)})}
break
case 'setppbot':
case 'setpp': {
if (!isCreator) return m.reply(mess.owner)
if (/image/g.test(mime)) {
let media = await conn.downloadAndSaveMediaMessage(qmsg)
await conn.updateProfilePicture(botNumber, {url: media})
await fs.unlinkSync(media)
m.reply(mess.done)
} else return m.reply(example('dengan mengirim foto'))
}
break
case 'setppbotpanjang':
case 'setpppanjang': {
if (!isCreator) return m.reply(mess.owner)
if (/image/g.test(mime)) {
var medis = await conn.downloadAndSaveMediaMessage(qmsg, 'ppbot.jpeg')
var { img } = await generateProfilePicture(medis)
await conn.query({
tag: 'iq',
attrs: {
to: botNumber,
type:'set',
xmlns: 'w:profile:picture'
},
content: [
{
tag: 'picture',
attrs: { type: 'image' },
content: img
}
]
})
fs.unlinkSync(medis)
m.reply(mess.done)
} else return m.reply(example('dengan mengirim foto'))
}
break
case 'deleteppbot':
case 'delppbot': {
if (!isCreator) return m.reply(mess.owner)
await conn.removeProfilePicture(conn.user.id)
m.reply(mess.done)
}
break
case 'setname':
case 'setbotname': {
if (!isCreator) return m.reply(mess.owner)
if (!text) return m.reply(example('teksnya'))
await conn.updateProfileName(text)
m.reply(mess.done)
}
break
case 'setbotbio':
case 'setbio': {
if (!isCreator) return m.reply(mess.owner)
if (!text) return m.reply(example('teksnya'))
await conn.updateProfileStatus(text)
m.reply(mess.done)
}
break
case 'listsampah': {
if (!isCreator) return m.reply(mess.owner)
let all = fs.readdirSync('./sampah')
if (all.length == 0) return m.reply('Tidak ada sampah')
let teks = `\n*LIST ALL SAMPAH SYSTEM*\n\n*Total sampah :* ${all.length}\n\n`
for (let e of all) {
teks += `◦ ${e}\n`
} 
m.reply(teks)
}
break
case 'delsampah':
case 'boost': {
if (!isCreator) return m.reply(mess.owner)
let sampah = 'sampah'
fs.readdir(sampah, (err, files) => {
if (files.length == 0) return m.reply('Tidak ada sampah')
for (const file of files) {
if (file !== 'sampah') {
fs.unlink(path.join(sampah, file), err => {
if (err) return m.reply('Tidak ada sampah')
})}}
m.reply(`Berhasil Menghapus *${files.length}* file sampah`)})
}
break
case 'broadcastgc':
case 'bcgc': {
if (!isCreator) return m.reply(mess.owner)
if (!text) return m.reply(example('teksnya dengan mengirim foto/video'))
let teksnya = `${text}`
let total = 0
let getGroups = await conn.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let usergc = groups.map((v) => v.id)
let time = sleep(5000 * Number(usergc.length))
await m.reply(`Memproses Mengirim Pesan Teks & Media Ke *${usergc.length} Grup*

Mohon Bersabar Broadcast Ini Delay 5 Detik/Share`)
for (let jid of usergc) {
try {
if (/image/.test(mime)) {
let media = await quoted.download()
await conn.sendMessage(m.chat, { image: { url: media }, caption: teksnya }, { quoted: qtoko })
} else if (/video/.test(mime)) {
let media = await quoted.download()
await conn.sendMessage(jid, { video: { url: media }, caption: teksnya }, { quoted: qtoko })
} else if (text) {
await conn.sendMessage(jid, { text: teksnya }, { quoted: qtoko })
}
total += 1
} catch {}
await sleep(5000)
}
m.reply(`Berhasil Mengirim Pesan Teks Ke *${total} Grup*`)
}
break
case 'setthumbnail':
case 'setthumb': {
if (!isCreator) return m.reply(mess.owner)
if (/image/g.test(mime)) {
let imgnya = await conn.downloadAndSaveMediaMessage(qmsg)
let cover = await catbox(imgnya)
thumbnail = cover.url
m.reply(mess.done)
} else return m.reply('dengan mengirim foto')
}
break
case 'del':
case 'delete': {
if (m.isGroup) {
if (!isCreator && !isAdmins) return m.reply(mess.admin)
if (!m.quoted) return m.reply("Reply pesan yang ingin di *Delete*")
if (m.quoted.sender == botNumber) {
conn.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: true, id: m.quoted.id, participant: m.quoted.sender}})
} else {
if (!isBotAdmins) return m.reply(mess.botadmin)
conn.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.quoted.id, participant: m.quoted.sender}})
}} else {
if (!isCreator) return m.reply(mess.owner)
if (!m.quoted) return m.reply("Reply pesan yang ingin di *Delete*")
conn.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.quoted.id, participant: m.quoted.sender}})
}}
break
case 'listpc': {
if (!isCreator) return m.reply(mess.owner)
let anulistp = await store.chats.all().filter(v => v.id.endsWith('.net')).map(v => v.id)
let teks = `  *乂 LIST ALL CHAT*\n  Total Chat : *${anulistp.length}* Chat\n\n`
for (let i of anulistp) {
let nama = store.messages[i].array[0].pushName
teks += `  *◦ Name :* ${nama}\n  *◦ User :* @${i.split('@')[0]}\n  *◦ Chat :* https://wa.me/${i.split('@')[0]}\n\n`}
conn.sendMessage(m.chat, { text: teks }, { quoted: m })
}
break
case 'listgc': {
if (!isCreator) return m.reply(mess.owner)
let gcall = Object.values(await Reza.groupFetchAllParticipating().catch(_=> null))
let listgc = `  *乂 LIST ALL GROUP*\n  Total *${gcall.length}* Group`
for (let u of gcall) {
listgc += `\n\n  *◦ Nama :* ${u.subject}\n  ◦ *ID :* ${u.id}\n  *◦ Pembuat :* ${u.owner ? '@' + u.owner.split('@')[0] : 'Sudah keluar'}`
}
conn.sendMessage(m.chat, { text: listgc }, { quoted: m })
}
break

//================== [ MAIN MENU ] ==================//
case 'tqto': {
let cu = `Hallo Sis, here are the names who have been registered in creating/helping in the development of this script

*BIG TAHNKS TO*

> - Varrel Bastian ( Administrator XVP,Base, & Developer )
>  Veront Bastian [ - ]
> Xiaoyu [ Ceo Of XVP ]
> Ciaaa [ Secretary XVP ]
> Zhang Fei [ Manager XVP ]`
conn.sendMessage(m.chat, {
text: cu,
contextInfo: {
externalAdReply: {
showAdAttribution: true,
title: '',
body: 'Special Thanks To',
thumbnailUrl: thumbnail,
sourceUrl: global.linkgc,
mediaType: 1,
renderLargerThumbnail: true
}}
})
}
break
case 'owner':
case 'developer':
case 'creator': {
conn.sendContact(m.chat, [owner], "Telfon/Vc & Spam = Block", null, {contextInfo: {
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true, 
thumbnailUrl: thumbnail, 
title: `© Copyright ${global.ownername}`, 
renderLargerThumbnail: true, 
sourceUrl: global.linkgc, 
mediaType: 1
}}})
}
break
case 'esceh':
case 'sc':
case 'script': {
let script = `*## Jual Script bot WhatsApp*

\`Script bot ini dilengkapi fitur:\`
* *Download:* Unduh video, musik, gambar, dan file dengan mudah.
* *Search:* Temukan video, musik, gambar, dan file favoritmu dan dapatkan informasi terupdate.
* *Tools:* Alat praktis untuk berbagai kebutuhan, seperti kalkulator, konverter, dan lainnya.
* *AI:*  Akses kecerdasan buatan untuk menjawab pertanyaan dan mendapatkan saran.
* *Game:* Mainkan game seru di WhatsApp dengan teman-temanmu.
* *Dan masih banyak fitur-fitur menarik lagi!*

\`Keterangan:\`
* No Encryption.
* Mendapatkan update selamanya.
* Free fix selamanya.
* Tanpa Menggunakan Sistem Apikey

\`Harga:\`
Dengan Harga *Rp.60,000* Kamu sudah mendapatkan script bot WhatsApp ini.

\`Contoh/tester:\`
WhatsApp Bot: [https://wa.me/6289525288796]

\`Minat atau tanya-tanya bisa hubungi:\`
WhatsApp: [https://wa.me/628893609279]
Telegram: [https://t.me/xiaoyutiersss]`
conn.sendMessage(m.chat, { image: { url: global.thumbnail }, caption: script }, { quoted: qtoko })
}
break
case 'runtime': {
m.reply(`Bot Aktif Selama ${runtime(process.uptime())}`)
}
break
case 'totalfitur': {
m.reply(`Total Fitur Bot Yang Dimiliki Saat Ini Adalah ${totalFitur()}`)
}
break
case 'ping': { 
const start = performance.now()
const cpus = os.cpus()
const uptimeSeconds = os.uptime()
const uptimeDays = Math.floor(uptimeSeconds / 86400)
const uptimeHours = Math.floor((uptimeSeconds % 86400) / 3600)
const uptimeMinutes = Math.floor((uptimeSeconds % 3600) / 60)
const uptimeSecs = Math.floor(uptimeSeconds % 60)
const totalMem = os.totalmem()
const freeMem = os.freemem()
const usedMem = totalMem - freeMem
const muptime = runtime(process.uptime()).trim()
const formattedUsedMem = formatSize(usedMem)
const formattedTotalMem = formatSize(totalMem)
const loadAverage = os.loadavg().map(avg => avg.toFixed(2)).join(", ")
const speed = (performance.now() - start).toFixed(3)
let serverInfo = `INFORMASI SERVER BOT

- CPU Cores: ${cpus.length}
- CPU Model: ${cpus[0].model}
- Platform: ${os.platform()}
- Architecture: ${os.arch()}
- Uptime: ${uptimeDays}d ${uptimeHours}h ${uptimeMinutes}m ${uptimeSecs}s
- RAM: ${formattedUsedMem} / ${formattedTotalMem}
- Load Average (1, 5, 15 min): ${loadAverage}
- Response Time: ${speed} seconds
- Runtime: ${muptime}`
m.reply(serverInfo)
}
break
case 'registrasi':
case 'registered':
case 'daftar':
case 'regis':
case 'register': {
if (db.data.users[m.sender].registered) return m.reply('Kamu sudah terdaftar')
let sn = crypto.createHash('md5').update(m.sender).digest('hex');
db.data.users[m.sender].name = `${pushname}`
db.data.users[m.sender].registered = true
db.data.users[m.sender].sn = sn
let capt = `*R E G I S T E R - S U C C E S S*\n`
capt += `* *Name* : ${pushname}\n`
capt += `* *Number* : ${m.sender.split('@')[0]}\n`
capt += `* *Serial Number* : ${sn}`
let p = await new canvafy.Security()
.setAvatar(ppuser)
.setBackground("image", "https://telegra.ph/file/f1c908e8e76be968e42f3.jpg")
.setCreatedTimestamp(Date.now())
.setSuspectTimestamp(1)
.setBorder("#f0f0f0")
.setLocale("id") // country short code - default "en"
.setAvatarBorder("#f0f0f0")
.setOverlayOpacity(0.9)
.build();
await conn.sendFile(m.chat, p, '', capt, m)
}
break
case 'mysn':
case 'ceksn':
case 'sn': {
if (!db.data.users[m.sender].registered) return m.reply(mess.regis)
let sn = crypto.createHash('md5').update(m.sender).digest('hex');
m.reply(`${sn}`)
}
break
case 'unreg': {
if (!db.data.users[m.sender].registered) return m.reply(mess.regis)
if (!args[0]) return m.reply(example('snnya'))
let sn = crypto.createHash('md5').update(m.sender).digest('hex')
if (args[0] !== sn) return m.reply('Serial number yang kamu masukkan salah!')
db.data.users[m.sender].registered = false
m.reply('Berhasil menghapus datamu, sekarang kamu tidak terdaftar lagi.')
}
break
case 'afk': {
if (!m.isGroup) return m.reply(mess.group)
await conn.sendMessage(m.chat, {text: `@${m.sender.split('@')[0]} _Telah afk_\n${text ? '*Dengan alasan*'+' '+'*'+text+'*' : '*Tanpa Alasan*'}`, contextInfo: {mentionedJid: [m.sender]}}, {quoted: m})
let anu = db.data.users[m.sender]
anu.afk = + new Date
anu.afkAlasan = `${text ? text : 'Tanpa Alasan'}`
}
break

//================== [ GROUP MENU ] ==================//
case 'add': {
if (!m.isGroup) return m.reply(mess.group)
if (!isAdmins) return m.reply(mess.admin)
if (!isBotAdmins) return m.reply(mess.botAdmin)
if (!args[0]) return m.reply(example('nomornya'))
var teks = text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
var cek = await conn.onWhatsApp(`${teks.split('@')[0]}`)
if (cek.length < 1) return m.reply("Nomor Tersebut Tidak Terdaftar Di WhatsApp")
if (!isBotAdmins || !groupMetadata.memberAddMode) return m.reply("Gagal Menambahkan Member, Karna Admin Tidak Mengizinkam Peserta Dapat Add Member")
var a = await conn.groupParticipantsUpdate(m.chat, [teks], 'add')
if (a[0].status == 200) return m.reply(`Berhasil Menambahkan ${teks.split('@')[0]} Kedalam Grup Ini`)
if (a[0].status == 408) return m.reply(`Gagal Menambahkan ${teks.split('@')[0]} Ke Dalam Grup Ini, Karna Target Tidak Mengizinkan Orang Lain Dapat Menambahkan Dirinya Ke Dalam Grup`)
if (a[0].status == 409) return m.reply(`Dia Sudah Ada Di Dalam Grup Ini!`)
if (a[0].status == 403) return m.reply(`Gagal Menambahkan ${teks.split('@')[0]} Ke Dalam Grup Ini, Karna Target Tidak Mengizinkan Orang Lain Dapat Menambahkan Dirinya Ke Dalam Grup`)
}
break
case 'kick': {
if (!m.isGroup) return m.reply(mess.group)
if (!isAdmins) return m.reply(mess.admin)
if (!isBotAdmins) return m.reply(mess.botAdmin)
if (text || m.quoted) {
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await conn.groupParticipantsUpdate(m.chat, [users], 'remove').then((res) => conn.sendMessage(m.chat, {text: `Berhasil Mengeluarkan @${users.split('@')[0]} Dari Grup Ini`, mentions: [`${users}`]}, {quoted: m})).catch((err) => m.reply(err.toString()))
} else return m.reply(example('nomornya/@tag'))
}
break
case 'promote': {
if (!m.isGroup) return m.reply(mess.group)
if (!isAdmins) return m.reply(mess.admin)
if (!isBotAdmins) return m.reply(mess.botAdmin)
if (m.quoted || text) {
let target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await conn.groupParticipantsUpdate(m.chat, [target], 'promote').then((res) => m.reply(`Berhasil Menjadikan ${target.split('@')[0]} Sebagai Admin Grup Ini`)).catch((err) => m.reply(err.toString()))
} else return m.reply(example('nomornya/@tag'))
}
break
case 'demote': {
if (!m.isGroup) return m.reply(mess.group)
if (!isAdmins) return m.reply(mess.admin)
if (!isBotAdmins) return m.reply(mess.botAdmin)
if (m.quoted || text) {
let target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await conn.groupParticipantsUpdate(m.chat, [target], 'demote').then((res) => m.reply(`Berhasil Memberhentikan ${target.split('@')[0]} Sebagai Admin Grup Ini`)).catch((err) => m.reply(err.toString()))
} else return m.reply(example('nomornya/@tag'))
}
break
case 'setnamagc':
case 'namagc': {
if (!m.isGroup) return m.reply(mess.group)
if (!isAdmins) return m.reply(mess.admin)
if (!isBotAdmins) return m.reply(mess.botAdmin)
if (!text) return m.reply(example('teksnya'))
conn.groupUpdateSubject(m.chat, text)
m.reply(mess.done)
}
break
case 'setdeskgc':
case 'deskgc': {
if (!m.isGroup) return m.reply(mess.group)
if (!isAdmins) return m.reply(mess.admin)
if (!isBotAdmins) return m.reply(mess.botAdmin)
if (!text) return m.reply(example('teksnya'))
conn.groupUpdateDescription(m.chat, text)
m.reply(mess.done)
}
break
case 'editinfogc':
case 'gc': {
if (!m.isGroup) return m.reply(mess.group)
if (!isAdmins) return m.reply(mess.admin)
if (!isBotAdmins) return m.reply(mess.botAdmin)
if (args[0] == 'open') {
conn.groupSettingUpdate(m.chat, 'not_announcement')
m.reply(mess.done)
} else if (args[0] == 'close') {
conn.groupSettingUpdate(m.chat, 'announcement')
m.reply(mess.done)
} else return m.reply(example('open/close'))
}
break
case 'revoke':
case 'resetlinkgc':
case 'resetlink': {
if (!m.isGroup) return m.reply(mess.group)
if (!isAdmins) return m.reply(mess.admin)
if (!isBotAdmins) return m.reply(mess.botAdmin)
conn.groupRevokeInvite(m.chat)
m.reply(mess.done)
}
break
case 'hidetag':
case 'ht':
case 'h': {
if (!m.isGroup) return m.reply(mess.group)
if (!isAdmins) return m.reply(mess.admin)
if (!isBotAdmins) return m.reply(mess.botAdmin)
if (!m.quoted && !text) return m.reply(example('teksnya/replyteks'))
var teks = m.quoted ? m.quoted.text : text
var member = await groupMetadata.participants.map(e => e.id)
conn.sendMessage(m.chat, {text: teks, mentions: [...member]}, {quoted: m})
}
break
case 'ongc':
case 'enablegc': {
if (!m.isGroup) return m.reply(mess.group)
if (!isAdmins) return m.reply(mess.admin)
if (!isBotAdmins) return m.reply(mess.botAdmin)
if (/gcpanel/gi.test(text)) {
db.data.chats[m.chat].panel = true
m.reply("Berhasil Menyalakan *Reseller Panel*")
} else if (/gcsubdo/gi.test(text)) {
db.data.chats[m.chat].subdo = true
m.reply("Berhasil Menyalakan *Reseller Subdomain*")
} else if (/status/gi.test(text)) {
var teks = `S T A T U S - G R O U P
◦ Gc Panel : ${db.data.chats[m.chat].panel ? "Aktif ✅" : "Tidak Aktif ❌"}
◦ Gc Subdo : ${db.data.chats[m.chat].subdo ? "Aktif ✅" : "Tidak Aktif ❌"}`
m.reply(teks)
} else return m.reply(example(`gcpanel\n\n*List Options :*\ngcpanel | gcsubdo\n\nKetik *${cmd} status* untuk melihat status`))
}
break
case 'offgc':
case 'disablegc': {
if (!m.isGroup) return m.reply(mess.group)
if (!isAdmins) return m.reply(mess.admin)
if (!isBotAdmins) return m.reply(mess.botAdmin)
if (/gcpanel/gi.test(text)) {
db.data.chats[m.chat].panel = false
m.reply("Berhasil Mematikan *Reseller Panel*")
} else if (/gcsubdo/gi.test(text)) {
db.data.chats[m.chat].subdo = false
m.reply("Berhasil Mematikan *Reseller Subdomain*")
} else if (/status/gi.test(text)) {
var teks = `S T A T U S - G R O U P
◦ Gc Panel : ${db.data.chats[m.chat].panel ? "Aktif ✅" : "Tidak Aktif ❌"}
◦ Gc Subdo : ${db.data.chats[m.chat].subdo ? "Aktif ✅" : "Tidak Aktif ❌"}`
m.reply(teks)
} else return m.reply(example(`gcpanel\n\n*List Options :*\ngcpanel | gcsubdo\n\nKetik *${cmd} status* untuk melihat status`))
}
break
case 'opentime': {
if (!m.isGroup) return m.reply(mess.group)
if (!isAdmins) return m.reply(mess.admin)
if (!isBotAdmins) return m.reply(mess.botAdmin)
if (args[1] == 'second') {
var timer = args[0] * `1000`
} else if (args[1] == 'minute') {
var timer = args[0] * `60000`
} else if (args[1] == 'hour') {
var timer = args[0] * `3600000`
} else if (args[1] == 'day') {
var timer = args[0] * `86400000`
} else {
return m.reply('*Choose:*\nsecond\nminute\nhour\n\n*Example*\n10 second')
}
m.reply(`Open Time ${q} Starting from now`)
setTimeout(() => {
var nomor = m.participant
const open = `*On time* Group Opened By Admin\n Now Members Can Send Messages`
conn.groupSettingUpdate(from, 'not_announcement')
m.reply(open)
}, timer)
}
break
case 'closetime': {
if (!m.isGroup) return m.reply(mess.group)
if (!isAdmins) return m.reply(mess.admin)
if (!isBotAdmins) return m.reply(mess.botAdmin)
if (args[1] == 'second') {
var timer = args[0] * `1000`
} else if (args[1] == 'minute') {
var timer = args[0] * `60000`
} else if (args[1] == 'hour') {
var timer = args[0] * `3600000`
} else if (args[1] == 'day') {
var timer = args[0] * `86400000`
} else {
return m.reply('*Choose:*\nsecond\nminute\nhour\n\n*Example*\n10 second')
}
m.reply(`Close Time ${q} Starting from now`)
setTimeout(() => {
var nomor = m.participant
const close = `*On time* Group Closed By Admin\nNow Only Admins Can Send Messages`
conn.groupSettingUpdate(from, 'announcement')
m.reply(close)
}, timer)
}
break

//================== [ GAME MENU ] ==================//
case 'tictactoe':
case 'ttt':
case 'ttc':
case 'xox': {
if (!m.isGroup) return m.reply(mess.group)
if (from in databasetictactoe) return m.reply(`Masih ada game yang blum selesai`)
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (!users) return m.reply(example('@tag'))
if (users === botNumber) return m.reply(`Tidak bisa bermain dengan bot!`)
if (users === m.sender) return m.reply(`Sad amat main ama diri sendiri`)
var hadiah = randomNumber(10, 20)
await m.reply(`@${m.sender.split('@')[0]} menantang @${users.split('@')[0]} untuk bermain TicTacToe\n\n*Kirim (Y/N)* untuk bermain\n\nHadiah : ${hadiah} balance`)
databasetictactoe[from] = {
id: from,
status: null,
hadiah: hadiah,
penantang: m.sender,
ditantang: users,
TicTacToe: ['1️⃣','2️⃣','3️⃣','4️⃣','5️⃣','6️⃣','7️⃣','8️⃣','9️⃣']
}
}
break
case 'delttt':
case 'delttc': {
if (!m.isGroup) return m.reply(mess.group)
if (!(from in databasetictactoe)) return m.reply(`Tidak ada sesi game tictactoe di grup ini`)
if (databasetictactoe[from].penantang.includes(m.sender)) {
delete databasetictactoe[from];
m.reply(`Berhasil menghapus sesi tictactoe di grup ini`)
} else if (databasetictactoe[from].ditantang.includes(m.sender)) {
delete databasetictactoe[from];
m.reply(`Berhasil menghapus sesi tictactoe di grup ini`)
} else {
m.reply(`Anda tidak bisa menghapus sesi tictactoe karena bukan pemain!`)
}
}
break
case 'suit': {
if (!m.isGroup) return m.reply(mess.group)
if (Object.values(databasesuit).find(v => v.id.startsWith('suit') && [v.penantang, v.ditantang].includes(m.sender))) return m.reply(`Selesaikan dulu suit mu yang sebelumnya`)
let froms = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (m.quoted || text) {
if (froms === botNumber) return m.reply(`Tidak bisa bermain suit dengan bot!`)
if (froms === m.sender) return m.reply(`Tidak bisa bermain dengan diri sendiri!`)
if (Object.values(databasesuit).find(v => v.id.startsWith('suit') && [v.penantang, v.ditantang].includes(froms))) return m.reply(`Orang yang kamu tantang sedang bermain suit bersama orang lain`)
let hadiah = randomNumber(2000, 3000)
let timeout = 60 * 1000
let id = 'suit_' + Date.now()
databasesuit[id] = {
id: id,
penantang: m.sender,
ditantang: froms,
status: 'WAIT',
hadiah: hadiah,
chat: await conn.sendMessage(m.chat, {text: `*🎮 GAME SUIT 🎮*\n\n@${m.sender.split('@')[0]} menantang @${froms.split('@')[0]} untuk bermain suit\n\nKetik *Y atau N* untuk bermain\nY = menerima suit\nN = menolak suit\n\nHadiah : *$${hadiah}* balance`, contextInfo: {mentionedJid: [froms, m.sender]}}, {quoted: m}),
timeout: timeout,
waktu: setTimeout(() => {
if (databasesuit[id]) conn.sendMessage(m.chat, {text: `Waktu habis! @${froms.split('@')[0]} tidak merespon suit\nGame dibatalkan!`, contextInfo: {mentionedJid: [froms]}}, {quoted: databasesuit[id].chat})
delete databasesuit[id]
}, timeout)
}
} else m.reply(example('@tagtarget'))
}
break
case 'tebakbomb':
case 'bomb': {
if (!m.isGroup) return m.reply(mess.group)
if (m.chat in conn.bomb) return conn.sendMessage(m.chat, { text: `Masih ada game yang belum terselsaikan!"` }, { quoted: conn.bomb[m.chat][0] })
conn.bomb = conn.bomb ? conn.bomb : {};
let id = m.chat,
timeout = 180000;
const bom = ['💥', '✅', '✅', '✅', '✅', '✅', '✅', '✅', '✅'].sort(() => Math.random() - 0.5);
const number = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣'];
const array = bom.map((v, i) => ({
emot: v,
number: number[i],
position: i + 1,
state: false
}));
let teks = `*🎮 GAME TEBAK BOM 🎮*\n\nKirim angka *1* - *9* untuk membuka *9* kotak nomor di bawah ini :\n\n`;
for (let i = 0; i < array.length; i += 3) teks += array.slice(i, i + 3).map(v => v.state ? v.emot : v.number).join('') + '\n';
teks += `\nWaktu : *${((timeout / 1000) / 60)} menit*\nHadiah : *Random Balance*\n\nApabila mendapat kotak yang berisi bom maka *Hadiah* tidak di berikan`;
let msg = await conn.sendMessage(m.chat, { text: teks }, { quoted: conn.bomb[id] ? conn.bomb[id][0] : m })
let { key } = msg
let v;
conn.bomb[id] = [
msg,
array,
setTimeout(() => {
v = array.find(v => v.emot == '💥');
if (conn.bomb[id]) conn.sendMessage(m.chat, { text: `*Waktu habis*\n\nKotak yang berisi bom ${v.number} tidak terbuka\nGame dihentikan!` }, { quoted: conn.bomb[id][0] })
delete conn.bomb[id];
}, timeout),
key
];
}
break
case 'casino': {
if (!m.isGroup) return m.reply(mess.group)
let users = global.db.data.users[m.sender]
conn.casino = conn.casino ? conn.casino : {}
if (m.chat in conn.casino) return m.reply('Masih Ada Yang Melakukan Casino Disini, Tunggu Sampai Selesai!!')
else conn.casino[m.chat] = true
try {
let randomaku = `${Math.floor(Math.random() * 101)}`.trim()
let randomkamu = `${Math.floor(Math.random() * 81)}`.trim() //hehe Biar Susah Menang :v
let Aku = (randomaku * 1)
let Kamu = (randomkamu * 1)
let count = parseInt(args[0])
count = count ? /all/i.test(count) ? Math.floor(users.balance / 1) : parseInt(count) : args[0] ? parseInt(args[0]) : 1
count = Math.max(1, count)
if (args.length < 1) return m.reply(example('taruhannya'))
if (users.balance >= count * 1) {
users.balance -= count * 1
if (Aku > Kamu) {
m.reply(`💰 Casino 💰\n*${pushname}:* ${Kamu} Point\n*${global.botname}:* ${Aku} Point\n\n*Kamu Kalah*\nKamu Kehilangan ${count} Balance`)
} else if (Aku < Kamu) {
users.balance += count * 2
m.reply(`💰 Casino 💰\n*${pushname}:* ${Kamu} Point\n*${global.botname}:* ${Aku} Point\n\n*Kamu Kalah*\nKamu Mendapatkan ${count * 2} balance`)
} else {
users.balance += count * 1
m.reply(`💰 Casino 💰\n*${pushname}:* ${Kamu} Point\n*${global.botname}:* ${Aku} Point\n\n*Seri*\nKamu Mendapatkan ${count * 1} balance`)
}
} else m.reply(`Balance Kamu Tidak Mencukupi Untuk Casino Silahkan *bermain game* Terlebih Dahulu!`)
} catch (e) {
console.log(e)
m.reply(mess.error)
} finally {
delete conn.casino[m.chat]
}
}
break
case 'bonanza': {
if (!m.isGroup) return m.reply(mess.group)
let user = global.db.data.users[m.sender]
if (args.length < 2) return m.reply(example('taruhannya spinnya'))
let betAmount = parseInt(args[0]);
let spinCount = parseInt(args[1]);
if (isNaN(betAmount) || betAmount <= 0 || betAmount > 30000) {
return conn.reply(m.chat, 'Jumlah taruhan tidak valid, maksimal taruhan 30.000.', m);
}
if (isNaN(spinCount) || spinCount <= 0 || spinCount > 20) {
return conn.reply(m.chat, 'Jumlah spin harus antara 1 hingga 20.', m);
}
if (user.balance < betAmount) {
return conn.reply(m.chat, 'Balance kamu tidak cukup untuk taruhan ini.', m);
}
user.balance -= betAmount;
let singleBet = betAmount / spinCount;
let fruits = ['🍌', '🍎', '🍇', '🍊', '🥭'];
let fruitValues = {
'🍌': 100,
'🍎': 50,
'🍇': 90,
'🍊': 70,
'🥭': 40
};
let winPatterns = [
['🍎', '🍎', '🍎', '🍎'],
['🍌', '🍌', '🍌', '🍌'],
['🍇', '🍇', '🍇', '🍇'],
['🍊', '🍊', '🍊', '🍊'],
['🥭', '🥭', '🥭', '🥭'],
['🍎', '🍎', '🍎'],
['🍌', '🍌', '🍌'],
['🍇', '🍇', '🍇'],
['🍊', '🍊', '🍊'],
['🥭', '🥭', '🥭'],
['🥭'],
['🥭', '🍌', '🍎'],
['🍎'],
['🥭'],
['🍇']
];
let wins = 0;
let losses = 0;
let totalWinAmount = 0;
let totalLossAmount = 0;
let bigWins = 0;
let superWins = 0;
let winFruits = { '🍌': 0, '🍎': 0, '🍇': 0, '🍊': 0, '🥭': 0 };
let scatterWins = 0;
const generateSpinResult = () => {
let result = [];
for (let i = 0; i < 4; i++) {
let row = [];
for (let j = 0; j < 5; j++) {
row.push(fruits[Math.floor(Math.random() * fruits.length)]);
}
result.push(row);
}
return result;
};
const checkWin = (result) => {
for (let pattern of winPatterns) {
for (let row of result) {
let joinedRow = row.join('');
if (joinedRow.includes(pattern.join(''))) {
let fruit = pattern[0];
if (pattern.length === 4) {
scatterWins++;
totalWinAmount += singleBet * fruitValues[fruit];
winFruits[fruit]++;
return 'Scatter Win';
} else {
wins++;
totalWinAmount += singleBet * fruitValues[fruit];
winFruits[fruit]++;
return 'Win';
}
}
}
}
return 'Lose';
};
let initialMessage = await conn.reply(m.chat, `╭──────────────────\n│ *👤nama*: @${m.sender.split('@')[0]}\n│ *🎰spin*: ${spinCount}\n│ *🪙bet*: ${betAmount}\n╰──────────────────\n           ❃𝗙𝗥𝗨𝗜𝗧 𝗦𝗣𝗜𝗡❃`, m);
for (let i = 0; i < spinCount; i++) {
await new Promise(resolve => setTimeout(resolve, 1000));
let spinResult = generateSpinResult();
let spinText = spinResult.map(row => `┃ ${row.join(' │ ')} ┃`).join('\n');
let spinStatus = checkWin(spinResult);
if (spinStatus === 'Lose') {
losses++;
totalLossAmount += singleBet;
}
let updateMessage = `╭──────────────────\n│ *👤nama*: @${m.sender.split('@')[0]}\n│ *🎰spin*: ${spinCount}\n│ *🪙bet*: ${betAmount}\n╰──────────────────\n           ❃𝗙𝗥𝗨𝗜𝗧 𝗦𝗣𝗜𝗡❃\n${spinText}`;
if (i === spinCount - 1) {
updateMessage += `\n╭──────────────────\n│ *🏆win*: ${totalWinAmount}\n│➞ 🍎 Apel: ${winFruits['🍎']}\n│➞ 🍌 Pisang: ${winFruits['🍌']}\n│➞ 🍇 Anggur: ${winFruits['🍇']}\n│➞ 🍊 Jeruk: ${winFruits['🍊']}\n│➞ 🥭 Mangga: ${winFruits['🥭']}\n│ *Lose*: ${totalLossAmount}\n│ *Scater*: ${scatterWins}\n╰──────────────────`;
}
await conn.relayMessage(m.chat, {
protocolMessage: {
key: initialMessage.key,
type: 14,
editedMessage: {
conversation: updateMessage
}
}
}, {});
}
user.balance += parseInt(totalWinAmount); // Mengembalikan uang kemenangan ke pengguna
};
break
case 'slot': {
if (!m.isGroup) return m.reply(mess.group)
let users = global.db.data.users[m.sender]
let reward = randomNumber(2000, 3000)
let emojis = ["💵", "🎫", "🎟️"]
let a = Math.floor(Math.random() * emojis.length)
let b = Math.floor(Math.random() * emojis.length)
let c = Math.floor(Math.random() * emojis.length)
let x = [],
y = [],
z = []
for (let i = 0; i < 3; i++) {
x[i] = emojis[a]
a++
if (a == emojis.length) a = 0
}
for (let i = 0; i < 3; i++) {
y[i] = emojis[b]
b++
if (b == emojis.length) b = 0
}
for (let i = 0; i < 3; i++) {
z[i] = emojis[c]
c++
if (c == emojis.length) c = 0
}
let end
if (a == b && b == c) {
end = `JACKPOT! *+${reward} point*`
users.balance += reward
} else if (a == b || a == c || b == c) {
end = `Hampir Beruntung! *+1 Limits*`
users.limit += 1
} else {
end = `LOSE! *-${reward} point*`
if (reward > users.balance) {
users.balance = 0
} else {
users.balance -= reward
}
}
let teks = `乂 *S L O T S*\n\n`
teks += `	[ ${x[0]} ${y[0]} ${z[0]} ]\n`
teks += `	[ ${x[1]} ${y[1]} ${z[1]} ]\n`
teks += `	[ ${x[2]} ${y[2]} ${z[2]} ]\n`
teks += `\n${end}`
m.reply(teks)
}
break

//================== [ RPG MENU ] ==================//
case 'ceklimit':
case 'limit':
case 'me':
case 'my':
case 'balance':
case 'cekbalance':
case 'inv':
case 'inventori':
case 'inventory':
case 'profile':
case 'bag': {
let teks = `*── 「 INVENTORI 」 ──*

*PROFILE*
• 👤 Name : ${pushname}
• 📞 Number : ${m.sender.split('@')[0]}
• 🎟️ Limit : ${limitnya}
• 🎫 Balance : $${toRupiah(balancenya)}`
await conn.sendMessage(m.chat, { text: teks, contextInfo: { externalAdReply: { title: `${pushname} Profile & Bag`, body: 'Play RPG Games With Your Friends', thumbnailUrl: ppuser, sourceUrl: global.linkgc, mediaType: 1, renderLargerThumbnail: true }}}, { quoted: m })
}
break
case 'topglobal': {
if (args[0] === "limit") {
let ulimit = Object.entries(global.db.data.users).map(([key, value]) => {return {...value, jid: key}})
let sortedlimit = ulimit.map(toNumber('limit')).sort(sort('limit'))
let userslimit = sortedlimit.map(enumGetKey)
m.reply(`\n*🏆 LIST TOP GLOBAL LIMIT*\n\nKamu Top *${userslimit.indexOf(m.sender) + 1}* Limit dari *${userslimit.length}* Users

${sortedlimit.slice(0, 10).map(({ jid, limit }, i) => `${i + 1}. *Nama :* @${db.data.users[jid].name}\n*Nomor :* ${jid.split('@')[0]}\n*Limit :* ${limit}\n`).join('\n')}\n`)
} else if (args[0] === "balance") {
let ubalance = Object.entries(global.db.data.users).map(([key, value]) => {return {...value, jid: key}})
let sortedbalance = ubalance.map(toNumber('balance')).sort(sort('balance'))
let usersbalance = sortedbalance.map(enumGetKey)
m.reply(`\n*🏆 LIST TOP GLOBAL BALANCE*\n\nKamu Top *${usersbalance.indexOf(m.sender) + 1}* Balance dari *${usersbalance.length}* Users

${sortedbalance.slice(0, 10).map(({ jid, balance }, i) => `${i + 1}. *Nama :* @${db.data.users[jid].name}\n*Nomor :* ${jid.split('@')[0]}\n*Balance :* $${toRupiah(balance)}\n`).join('\n')}\n`)
} else return m.reply(example('limit/balance'))
}
break
case 'buylimit':
case 'belilimit': {
if (!args[0]) return m.reply(example('100\n\nHarga 1 *limit* = $1000 *balance*'))
if (isNaN(args[0])) return m.reply(example('20'))
if ((args[0]).includes('.')) return m.reply(example('20'))
let harga = 1000
let total = Number(parseInt(args[0]) * harga)
if (balancenya < total) return m.reply(`*Balance* kamu tidak cukup untuk membeli ${args[0]} *Limit!*\n\nDapatkan *Balance* dengan cara memainkan game`)
db.data.users[m.sender].limit += Number(args[0])
db.data.users[m.sender].balance -= total
m.reply(`Berhasil membeli *${args[0]}* limit, dengan *$${toRupiah(total)}* balance`)
}
break
case 'tflimit':
case 'transferlimit': {
if (!m.isGroup) return m.reply(mess.group)
let data = Object.keys(db.data.users)
let users = m.mentionedJid[0]
if (m.mentionedJid[0] || args[1]) {
if (!data.includes(m.mentionedJid[0])) return m.reply("User tidak terdaftar di database bot!")
if (limitnya < args[1]) return m.reply("*Limit* kamu tidak cukup!")
db.data.users[m.sender].limit -= Number(args[1])
db.data.users[m.mentionedJid[0]].limit += Number(args[1])
conn.sendMessage(m.chat, {text: `Berhasil mengirim limit ke @${users.split('@')[0]} sejumlah *${args[1]}*`, contextInfo: {mentionedJid: [m.mentionedJid[0]]}}, {quoted: m})
} else return m.reply(example('@tagtarget 100'))
}
break
case 'tfbalance':
case 'transferbalance': {
if (!m.isGroup) return m.reply(mess.group)
let users = m.mentionedJid[0]
let data = Object.keys(db.data.users)
if (!args[0] && !args[1]) return m.reply(example('@tagtarget 100'))
if (isNaN(args[1])) return m.reply(example('@tagtarget 100'))
if (args[1].includes('.')) return m.reply(example('@tagtarget 100'))
if (m.mentionedJid[0]) {
if (!data.includes(m.mentionedJid[0])) return m.reply("User tidak terdaftar di database bot!")
if (balancenya < args[1]) return m.reply('Balance kamu tidak cukup!')
db.data.users[m.sender].balance -= Number(args[1])
db.data.users[users].balance += Number(args[1])
conn.sendMessage(m.chat, {text: `Berhasil mengirim balance ke @${users.split('@')[0]} sejumlah *$${toRupiah(args[1])}*`, contextInfo: {mentionedJid: [users]}}, {quoted: m})
} else return m.reply(example('@tagtarget 100'))
}
break

//================== [ ANIME MENU ] ==================//
case 'animesearch': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('naruto'))
m.reply(mess.wait)
let anu = await searchAnime(text)
let teks = `乂 *A N I M E - S E A R C H*\n\n\n`
anu.map((v, i) => {
teks += `${i+1}. *Title* : ${v.title}\n`
teks += `*Url* : ${v.url}\n\n───────────────\n\n`
}).join('\n\n')
m.reply(teks)
uselimit()}
break
case 'animedetail': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('naruto'))
m.reply(mess.wait)
let more = String.fromCharCode(8206)
let readmore = more.repeat(4001)
let anime = await malScraper.getInfoFromName(text).catch(() => null)
if (!anime) return m.reply(mess.error)
let caption = `乂 *A N I M E - D E T A I L*

◦ *Title: ${anime.title}*
◦ *Type: ${anime.type}*
◦ *Premiered on: ${anime.premiered}*
◦ *Total Episodes: ${anime.episodes}*
◦ *Status: ${anime.status}*
◦ *Genres: ${anime.genres}
◦ *Studio: ${anime.studios}*
◦ *Score: ${anime.score}*
◦ *Rating: ${anime.rating}*
◦ *Rank: ${anime.ranked}*
◦ *Popularity: ${anime.popularity}*
◦ *Trailer: ${anime.trailer}*

*Synopsis ⤵️*
${readmore}
${anime.synopsis}`
conn.sendMessage(m.chat, { image: { url: anime.picture }, caption: caption }, { quoted: m })
uselimit()}
break

//================== [ SEARCH MENU ] ==================//
case 'ytplay':
case 'play': {
if (!text) return m.reply(example('dj plat kt'))
let wait = await conn.sendMessage(m.chat, {
text: `_Searching.. [ ${text} ] 🔍_`
}, {
quoted: m,
ephemeralExpiration: 86400
})
let search = await ytSearch(text)
let download = search.videos[Math.floor(Math.random() * search.videos.length)]
if (!search) return m.reply("Video Not Found, Try Another Title");
let { url } = download
await fetchJson(`https://widipe.com/download/ytdl?url=${url}`).then((data) => {
conn.sendMessage(m.chat, {
text: `_Mengirim.. [ ${text} ] 🔍_`,
edit: wait.key
}, {
quoted: m,
ephemeralExpiration: 86400
})
conn.sendMessage(m.chat, { audio: data.result.mp4, mimetype: 'audio/mpeg' }, { quoted: m })
conn.sendMessage(m.chat, {
react: {
text: '🎧',
key: m.key
}
})
}).catch((e) => m.reply(mess.error))
}
break
case 'yts':
case 'ytsearch': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('dj plat kt'))
m.reply(mess.wait)
await ytSearch(text).then(async (data) => {
if (data.all.length == 0) return m.reply(mess.error)
let teks = '\n*🔎Hasil Pencarian YOUTUBE*\n\n'
for (let i of data.all) {
teks += `*◦ Judul :* ${i.title}
*◦ Channel :* ${i.author.name}
*◦ Durasi :* ${i.timestamp}
*◦ Link Url :* ${i.url}\n\n`
}
m.reply(teks)
}).catch(err => m.reply(mess.error))
uselimit()}
break
case 'google':
case 'googlesearch': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('makanan'))
m.reply(mess.wait)
await googleSearch({'query': text}).then((res) => {
let teks = '\n*🔎Hasil Pencarian GOOGLE*\n\n'
for (let i of res) {
teks += `*◦ Judul :* ${i.title}
*◦ Deskripsi :* ${i.snippet}
*◦ Link Url :* ${i.link}\n\n`
}
m.reply(teks)
}).catch((e) => {
return m.reply(mess.error)
})
uselimit()}
break
case 'googleimage':
case 'gimage': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('wallpaper'))
m.reply(mess.wait)
await dylux.googleImage(text).then((res) => {
let result = res[Math.floor(Math.random() * res.length)]
conn.sendMessage(m.chat, { image: { url: result }, caption: mess.done }, { quoted: m })
}).catch(e => {m.reply(mess.error)})
uselimit()}
break
case 'pinterest':
case 'pin': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('wallpaper'))
m.reply(mess.wait)
await pinterest(text).then((res) => {
let result = res[Math.floor(Math.random() * res.length)]
conn.sendMessage(m.chat, { image: { url: result }, caption: mess.done }, { quoted: m })}
).catch(e => {m.reply(mess.error)})
uselimit()}
break
case 'tiktoksearch':
case 'ttsearch': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('jj epep'))
m.reply(mess.wait)
try {
let anu = await dann.search.tiktoks(text)
conn.sendMessage(m.chat, { video: { url: anu.no_watermark }, mimetype: 'video/mp4', caption: anu.title }, { quoted : m })
} catch (error) {
m.reply(mess.error)
}
uselimit()}
break
case 'chordgitar':
case 'chord': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('pilihan hatiku'))
m.reply(mess.wait)
await fetchJson(`https://widipe.com/chord?query=${text}`).then((data) => {
conn.sendMessage(m.chat, { text: `*Judul Lagu :* ${text}\n\n${data.result.chord}` }, { quoted: m })
}).catch((e) => m.reply(mess.error))
uselimit()}
break
case 'lyrics':
case 'lirik': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('pilihan hatiku'))
m.reply(mess.wait)
let res = await dylux.lyrics(text)
let cap = `*L I R I K - L A G U*\n\n*Title* : ${res.title}\n*Artist* : ${res.artist}\n*Lyrics* :\n${res.lyrics}`
conn.sendMessage(m.chat, { image: { url: res.image }, caption: cap }, { quoted: m })
uselimit()}
break
case 'npmjs': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('api-dylux'))
m.reply(mess.wait)
let res = await fetch(`http://registry.npmjs.com/-/v1/search?text=${text}`)
let {
objects
} = await res.json()
if (!objects.length) return m.reply( `Query "${text}" not found :/`)
let txt = objects.map(({
package: pkg
}) => {
return `*${pkg.name}* (v${pkg.version})\n_${pkg.links.npm}_\n_${pkg.description}_`
}).join`\n\n`
m.reply(txt)
uselimit()}
break
case 'stickersearch': {
if (!isPremium) return m.reply(mess.premium)
if (m.isGroup) return m.reply(mess.private)
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('doraemon'))
m.reply(mess.wait)
let anu = await stickersearch(text)
for (let rehs of anu.sticker_url) {
await sleep(5000)
await conn.sendImageAsSticker(m.chat, rehs, m, {
packname: packname,
author: author
})
}
uselimit()}
break

//================== [ DOWNLOAD MENU ] ==================//
case 'ytmp3':
case 'yta':
case 'ytaudio': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('linknya'))
if (!isUrl(text)) return m.reply(mess.linkvalid)
m.reply(mess.wait)
await fetchJson(`https://widipe.com/download/ytdl?url=${text}`).then((data) => {
conn.sendMessage(m.chat, { audio: data.result.mp4, mimetype: 'audio/mpeg' }, { quoted: m })
}).catch((e) => m.reply(mess.error))
uselimit()}
break
case 'ytmp4':
case 'ytv':
case 'ytvideo': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('linknya'))
if (!isUrl(text)) return m.reply(mess.linkvalid)
m.reply(mess.wait)
await fetchJson(`https://widipe.com/download/ytdl?url=${text}`).then((data) => {
let caption = `${data.result.title}

${data.result.description}`
conn.sendMessage(m.chat, { video: { url: data.result.mp4 }, caption: caption, mimetype: 'video/mp4' }, { quoted: m })
}).catch((e) => m.reply(mess.error))
uselimit()}
break
case 'tiktok':
case 'tt': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('linknya'))
if (!isUrl(text)) return m.reply(mess.linkvalid)
m.reply(mess.wait)
let data = await dylux.tiktok(text)
let json = data.result
let caption = `[ TIKTOK - DOWNLOAD ]\n\n`
caption += `◦ *Id* : ${json.id}\n`
caption += `◦ *Username* : ${json.author.nickname}\n`
caption += `◦ *Title* : ${(json.title)}\n`
caption += `◦ *Like* : ${(json.digg_count)}\n`
caption += `◦ *Comments* : ${(json.comment_count)}\n`
caption += `◦ *Share* : ${(json.share_count)}\n`
caption += `◦ *Play* : ${(json.play_count)}\n`
caption += `◦ *Created* : ${json.create_time}\n`
caption += `◦ *Size* : ${json.size}\n`
caption += `◦ *Duration* : ${json.duration}`
if (json.images) {
json.images.forEach(async (k) => {
await conn.sendMessage(m.chat, { image: { url: k }}, { quoted: m });
})
} else {
conn.sendMessage(m.chat, { video: { url: json.play }, mimetype: 'video/mp4', caption: caption }, { quoted: m })
setTimeout(() => {
conn.sendMessage(m.chat, { audio: { url: json.music }, mimetype: 'audio/mpeg' }, { quoted: m })
}, 3000)
}
uselimit()}
break
case 'ttaudio':
case 'tiktokaudio':
case 'tiktokmp3':
case 'ttmp3': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('linknya'))
if (!isUrl(text)) return m.reply(mess.linkvalid)
m.reply(mess.wait)
let data = await dylux.tiktok(text)
let json = data.result
conn.sendMessage(m.chat, { audio: { url: json.music }, mimetype: 'audio/mpeg' }, { quoted: m })
uselimit()}
break
case 'ttvideo':
case 'tiktokvideo':
case 'tiktokmp4':
case 'ttmp4': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('linknya'))
if (!isUrl(text)) return m.reply(mess.linkvalid)
m.reply(mess.wait)
let data = await dylux.tiktok(text)
let json = data.result
let caption = `[ TIKTOK - DOWNLOAD ]\n\n`
caption += `◦ *Id* : ${json.id}\n`
caption += `◦ *Username* : ${json.author.nickname}\n`
caption += `◦ *Title* : ${(json.title)}\n`
caption += `◦ *Like* : ${(json.digg_count)}\n`
caption += `◦ *Comments* : ${(json.comment_count)}\n`
caption += `◦ *Share* : ${(json.share_count)}\n`
caption += `◦ *Play* : ${(json.play_count)}\n`
caption += `◦ *Created* : ${json.create_time}\n`
caption += `◦ *Size* : ${json.size}\n`
caption += `◦ *Duration* : ${json.duration}`
conn.sendMessage(m.chat, { video: { url: json.play }, mimetype: 'video/mp4', caption: caption }, { quoted: m })
uselimit()}
break
case 'ttslide':
case 'tiktokslide':
case 'tiktokimg':
case 'ttimg': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('linknya'))
if (!isUrl(text)) return m.reply(mess.linkvalid)
m.reply(mess.wait)
let data = await dylux.tiktok(text)
let json = data.result
json.images.forEach(async (k) => {
await conn.sendMessage(m.chat, { image: { url: k }}, { quoted: m });
})
uselimit()}
break
case 'videy': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('linknya'))
if (!isUrl(text)) return m.reply(mess.linkvalid)
m.reply(mess.wait)
var anu = text.replace("v?id=", "")
var mannr = anu.replace("https://", "https://cdn.")
conn.sendMessage(m.chat, { video: { url: mannr + ".mp4" }, caption: mess.done }, { quoted: m })
uselimit()}
break
case 'capcut': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('linknya'))
if (!isUrl(text)) return m.reply(mess.linkvalid)
m.reply(mess.wait)
let cpct = await CapCut(text)
conn.sendMessage(m.chat, { video: { url: cpct.url }, mimetype: 'video/mp4', caption: cpct.title }, { quoted: m })
uselimit()}
break
case 'mf':
case 'mediafire': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('linknya'))
if (!isUrl(text)) return m.reply(mess.linkvalid)
m.reply(mess.wait)
let res = await mediafire(text)
conn.sendMessage(m.chat, { document: { url: res.data.link }, fileName: res.data.filename, mimetype: res.data.filetype, caption: mess.done }, { quoted: m })
uselimit()}
break
case 'instagram':
case 'igdl':
case 'ig': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('linknya'))
if (!isUrl(text)) return m.reply(mess.linkvalid)
m.reply(mess.wait)
let ig = await dylux.igdl(text)
let url = ig.result[0].url
if (url.includes('jpg')) {
if (m.isGroup) {
ig.result.forEach(async (k) => {
await conn.sendMessage(m.sender, { image: { url: k.url }}, { quoted: m })
})
m.reply(`All photos have been sent to your private chat`)
} else {
ig.result.forEach(async (k) => {
await conn.sendMessage(from, { image: { url: k.url }}, { quoted: m })
})
}
} else {
conn.sendMessage(m.chat, { video: { url: ig.result[0].url }, caption: mess.done }, { quoted: m })
}
uselimit()}
break
case 'facebook':
case 'fbdl':
case 'fb': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('linknya'))
if (!isUrl(text)) return m.reply(mess.linkvalid)
m.reply(mess.wait)
await fetchJson(`https://widipe.com/download/fbdown?url=${text}`).then((res) => {
if (!res.status) return m.reply(JSON.stringify(res, null, 2))
conn.sendMessage(m.chat, { video: {url: `${res.result.url.isHdAvailable == true ? res.result.url.urls[0].hd : res.result.url.urls[0].sd}`}, mimetype: 'video/mp4', caption: mess.done }, { quoted: m })
}).catch(e => m.reply(e.toString()))
}
break
case 'git':
case 'gitclone': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('link repositorinya'))
const regex = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i
if (!regex.test(args[0])) return m.reply(mess.linkvalid)
m.reply(mess.wait)
let [_, user, repo] = args[0].match(regex) || []
repo = repo.replace(/.git$/, '')
let urllink = `https://api.github.com/repos/${user}/${repo}/zipball`
let filename = (await fetch(urllink, { method: 'HEAD' })).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1]
conn.sendMessage(m.chat, { document: { url: urllink }, fileName: filename, mimetype: 'application/zip', caption: mess.done }, { quoted: m })
uselimit()}
break

//================== [ CONVERT MENU ] ==================//
case 'sticker':
case 'sgif':
case 's':
case 'stickergif':
case 'gif':
case 'stiker':
case 'stikergif': {
if (limitnya < 1) return m.reply(mess.limit)
if (/image|webp/g.test(mime)) {
await conn.downloadAndSaveMediaMessage(qmsg).then(res => {
conn.sendImageAsSticker(m.chat, res, m, { packname: global.packname, author: global.author })
fs.unlinkSync(res)})
} else if (/video/g.test(mime)) {
if ((qmsg).seconds > 15) return m.reply("Durasi vidio maksimal 15 detik!")
await conn.downloadAndSaveMediaMessage(qmsg).then(res => {
conn.sendVideoAsSticker(m.chat, res, m, { packname: global.packname, author: global.author })
fs.unlinkSync(res)})
} else {
return m.reply(example('dengan mengirim foto/video'))
}
uselimit()}
break
case 'stickerwm':
case 'swm':
case 'wm': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('packname|author dengan mengirim foto/video'))
m.reply(mess.wait)
let packname = text.split('|')[0] ? text.split('|')[0] : '-'
let author = text.split('|')[1] ? text.split('|')[1] : '-'
if (/image|webp/g.test(mime)) {
await conn.downloadAndSaveMediaMessage(qmsg).then(res => {
conn.sendImageAsSticker(m.chat, res, m, { packname: `${encodeURIComponent(packname)}`, author: `${encodeURIComponent(author)}` })
fs.unlinkSync(res)})
} else if (/video/g.test(mime)) {
if ((qmsg).seconds > 15) return m.reply("Durasi vidio maksimal 15 detik!")
await conn.downloadAndSaveMediaMessage(qmsg).then(res => {
conn.sendVideoAsSticker(m.chat, res, m, { packname: `${encodeURIComponent(packname)}`, author: `${encodeURIComponent(author)}` })
fs.unlinkSync(res)})
} else {
return m.reply(example('packname|author dengan mengirim foto/video'))}
uselimit()}
break
case 'cls': {
if (limitnya < 1) return m.reply(mess.limit)
if (!m.quoted) return m.reply(example('dengan mengirim sticker'))
m.reply(mess.wait)
let stiker = false
try {
let mime = m.quoted.mimetype || ''
if (!/webp/.test(mime)) return m.reply(example('dengan mengirim sticker'))
let img = await m.quoted.download()
if (!img) return m.reply('Failed to download sticker!')
stiker = await addExif(img, 'Buatan', pushname)
} catch (e) {
console.error(e)
if (Buffer.isBuffer(e)) stiker = e
else return m.reply('An error occurred: ' + e)
} finally {
if (stiker) conn.sendMessage(m.chat, { sticker: stiker }, { quoted: m })
else return m.reply(mess.error)
}
uselimit()}
break
case 'smeme': {
if (limitnya < 1) return m.reply(mess.limit)
if (!/image/.test(mime)) return m.reply(example('teks1|teks2 dengan mengirim foto'))
if (!text) return m.reply(example('teks1|teks2 dengan mengirim foto'))
m.reply(mess.wait)
let atas = text.split('|')[0] ? text.split('|')[0] : '-'
let bawah = text.split('|')[1] ? text.split('|')[1] : '-'
try {
let mee = await conn.downloadAndSaveMediaMessage(qmsg)
let mem = await catbox(mee)
let smeme = `https://api.memegen.link/images/custom/${encodeURIComponent(atas)}/${encodeURIComponent(bawah)}.png?background=${mem}`
let awikwok = await conn.sendImageAsSticker(m.chat, smeme, m, { packname: global.packname, author: global.author })
await fs.unlinkSync(awikwok)
} catch (e) {
m.reply(mess.error)
}
uselimit()}
break
case 'qc': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('teksnya'))
m.reply(mess.wait)
const obj = {
"type": "quote",
"format": "png",
"backgroundColor": "#FFFFFF",
"width": 512,
"height": 768,
"scale": 2,
"messages": [{
"entities": [],
"avatar": true,
"from": {
"id": 1,
"name": pushname,
"photo": {
"url": ppuser
}
},
"text": text,
"replyMessage": {}
}]
}
try {
const json = await axios.post('https://quotly.netorare.codes/generate', obj, {
headers: {
'Content-Type': 'application/json'
}
})
const buffer = Buffer.from(json.data.result.image, 'base64')
conn.sendImageAsSticker(m.chat, buffer, m, { packname: global.packname, author: global.author })
} catch (error) {
m.reply(mess.error)
}
uselimit()}
break
case 'qcimg': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('teksnya'))
m.reply(mess.wait)
const obj = {
"type": "quote",
"format": "png",
"backgroundColor": "#FFFFFF",
"width": 512,
"height": 768,
"scale": 2,
"messages": [{
"entities": [],
"avatar": true,
"from": {
"id": 1,
"name": pushname,
"photo": {
"url": ppuser
}
},
"text": text,
"replyMessage": {}
}]
}
try {
const json = await axios.post('https://quotly.netorare.codes/generate', obj, {
headers: {
'Content-Type': 'application/json'
}
})
const buffer = Buffer.from(json.data.result.image, 'base64')
conn.sendMessage(m.chat, { image: buffer, caption: mess.done }, { quoted: m })
} catch (error) {
m.reply(mess.error)
}
uselimit()}
break
case 'attp': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('teksnya'))
m.reply(mess.wait)
let attp = `https://widipe.com/attp?text=${text}`
conn.sendImageAsSticker(m.chat, attp, m, { packname: global.packname, author: global.author })
uselimit()}
break
case 'ttp': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('teksnya'))
m.reply(mess.wait)
let ttp = `https://widipe.com/ttp?text=${text}`
conn.sendImageAsSticker(m.chat, ttp, m, { packname: global.packname, author: global.author })
uselimit()}
break
case 'tourl': {
if (limitnya < 1) return m.reply(mess.limit)
if (!mime) return m.reply(example('dengan mengirim media'))
m.reply(mess.wait)
let media = await quoted.download()
let anu = await catbox(media)
conn.sendMessage(m.chat, { text: anu }, { quoted: m })
uselimit()}
break
case 'toimage':
case 'toimg': {
if (limitnya < 1) return m.reply(mess.limit)
if (!quoted) return m.reply(example('dengan mengirim sticker'))
if (!/webp/.test(mime)) return m.reply(example('dengan mengirim sticker'))
m.reply(mess.wait)
let media = await conn.downloadAndSaveMediaMessage(quoted)
let ran = await getRandom('.png')
exec(`ffmpeg -i ${media} ${ran}`, (err) => {
fs.unlinkSync(media)
if (err) throw err
let buffer = fs.readFileSync(ran)
conn.sendMessage(m.chat, { image: buffer, caption: 'Convert Webp To Image' }, { quoted: m })
fs.unlinkSync(ran)
})
uselimit()}
break
case 'toptv': {
if (limitnya < 1) return m.reply(mess.limit)
if (/video/.test(qmsg.mimetype)) {
if ((qmsg).seconds > 30) return m.reply("Durasi vidio maksimal 30 detik!")
let ptv = await generateWAMessageFromContent(m.chat, proto.Message.fromObject({ ptvMessage: qmsg }), { userJid: m.chat, quoted: m })
conn.relayMessage(m.chat, ptv.message, { messageId: ptv.key.id })
} else { 
return m.reply(example('dengam mengirim video'))
}
uselimit()}
break
case 'tomp4':
case 'tovideo':
case 'tovid': {
if (limitnya < 1) return m.reply(mess.limit)
if (!m.quoted) return m.reply(example('dengan mengirim sticker'))
if (!/webp/.test(mime)) return m.reply(example('dengan mengirim sticker'))
let media = await m.quoted.download()
let out = Buffer.alloc(0)
if (/webp/.test(mime)) {
out = await webp2mp4(media)
}
conn.sendMessage(m.chat, { video: { url: out, caption: 'Convert Webp To Video' }, gifPlayback: false }, { quoted: m })
uselimit()}
break
case 'togif': {
if (limitnya < 1) return m.reply(mess.limit)
if (!m.quoted) return m.reply(example('dengan mengirim sticker'))
if (!/webp/.test(mime)) return m.reply(example('dengan mengirim sticker'))
let media = await m.quoted.download()
let out = Buffer.alloc(0)
if (/webp/.test(mime)) {
out = await webp2mp4(media)
}
conn.sendMessage(m.chat, { video: { url: out, caption: 'Convert Webp To Gif' }, gifPlayback: true }, { quoted: m })
uselimit()}
break
case 'toaudio':
case 'tomp3':
case 'toaud': {
if (limitnya < 1) return m.reply(mess.limit)
if (!/video/.test(mime) && !/audio/.test(mime)) return m.reply(example('dengan mengirim vn/vidio'))
if ((qmsg).seconds > 30) return m.reply("Durasi vidio maksimal 30 detik")
m.reply(mess.wait)
await conn.downloadMediaMessage(qmsg).then(async (res) => {
let anu = await toAudio(res, 'mp4')
conn.sendMessage(m.chat, { audio: anu, mimetype: 'audio/mpeg' }, { quoted: m })
})
uselimit()}
break
case 'tovn':
case 'toptt': {
if (limitnya < 1) return m.reply(mess.limit)
if (!/video|audio/.test(mime) && !/audio/.test(mime)) return m.reply(example('dengan mengirim audio/vidio'))
m.reply(mess.wait)
await conn.downloadMediaMessage(qmsg).then(async (res) => {
let anu = await toPTT(res, 'mp4')
conn.sendMessage(m.chat, { audio: anu, mimetype: 'audio/mpeg', ptt: true }, { quoted: m }) 
})
uselimit()}
break
case 'toaksara': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('teksnya'))
m.reply(mess.wait)
try {
let anu = await latinToAksara(`${text}`)
conn.sendMessage(m.chat, { text: `*◦ Teks :*\n${anu}` }, { quoted: m })
} catch (e) {
console.log(e)
m.reply(mess.error)
}
uselimit()}
break
case 'tolatin': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('teksnya'))
m.reply(mess.wait)
try {
let anu = await aksaraToLatin(text)
conn.sendMessage(m.chat, { text: `*◦ Teks :*\n${anu}` }, { quoted: m })
} catch (e) {
console.log(e)
m.reply(mess.error)
}
uselimit()}
break

//================== [ TOOLS MENU ] ==================//
case 'cekcuaca':
case 'cuaca': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('samarinda'))

try {
const xmg = await fetchWeather(text)
const location = `${xmg.city}, ${xmg.country}`
const temperature = `${xmg.temperature.current}°C`
const description = xmg.condition.description
const iconUrl = xmg.condition.icon_url
const message = `🌦️ *Cuaca saat ini*
📍 *Lokasi:* ${location}
🌡️ *Suhu:* ${temperature}
🌈 *Kondisi:* ${description}`

conn.sendFile(m.chat, iconUrl, 'weather.png', message, m)
} catch (e) {
console.error(e);
m.reply(mess.error)
}
uselimit()}
break
case 'jarak': {
if (limitnya < 1) return m.reply(mess.limit)
var [me, to] = text.split`|`
if (!(from && to)) return m.reply(example(`samarinda|anggana`))
m.reply(mess.wait)
var data = await jarakkota(me, to)
if (data.img) return conn.sendMessage(m.chat, { image: data.img, caption: data.desc }, { quoted: m })
uselimit()}
break
case 'translate':
case 'tr': {
if (limitnya < 1) return m.reply(mess.limit)
if (text && m.quoted && m.quoted.text) {
let lang = text.slice(0, 2)
try {
let data = m.quoted.text
let result = await translate(`${data}`, { to: lang })
await m.reply(result.text)
} catch {
return m.reply(mess.error)
}
} else if (text) {
let lang = text.slice(0, 2)
try {
let data = text.substring(2).trim()
let result = await translate(`${data}`, { to: lang })
await m.reply(result.text)
} catch {
return m.reply(example('id hello i am bot'))
}
} else return m.reply(example('id hello i am bot'))
uselimit()}
break
case 'hd':
case 'tohd':
case 'remini': {
if (limitnya < 1) return m.reply(mess.limit)
if (!quoted) return m.reply(example('dengan mengirim foto'))
if (!/image/.test(mime)) return m.reply(example('dengan mengirim foto'))
m.reply(mess.wait)
let media = await quoted.download()
const This = await remini(media, "enhance");
conn.sendFile(m.chat, This, `${pushname}.png`, mess.done, m)
uselimit()}
break
case 'hdvid':
case 'hdvideo': {
if (limitnya < 1) return m.reply(mess.limit)
if (!mime) return m.reply(example('dengan mengirim video'))
let videoData = await conn.downloadAndSaveMediaMessage(quoted, 'video')
let output = './sampah/' + crypto.randomBytes(3).toString('hex') + '.mp4'
ffmpeg(videoData)
.format('mp4')
.size('?x1080')
.videoBitrate('2048k')
.videoCodec('libx264')
.fps(60)
.audioBitrate('192k')
.audioCodec('aac')
.output(output)
.on('end', () => {
conn.sendFile(m.chat, output, '', mess.done, m, (err) => {
fs.unlinkSync(output)
if (err) m.reply(mess.error)
})
})
.on('error', (err) => {
fs.unlinkSync(output)
console.error(err)
m.reply(mess.error)
})
.run()
uselimit()}
break
case 'tinyurl': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('linknya'))
await m.reply(mess.wait)
await fetchJson(`https://widipe.com/tinyurl?link=${text}`).then(async (res) => {
m.reply(`*◦ Link :* ${res.result}`)
}).catch(err => m.reply(mess.error))
uselimit()}
break
case 'jadianime':
case 'toanime': {
if (limitnya < 1) return m.reply(mess.limit)
if (!quoted) return m.reply(example('dengan mengirim foto'))
if (!/image/.test(mime)) return m.reply(example('dengan mengirim foto'))
m.reply(mess.wait)
let media = await quoted.download()
let url = await catbox(media)
let dat = await await fetchJson(`https://api.junn4.my.id/ai/toanime?url=${url}`)
await conn.sendMessage(m.chat, { image: { url: dat.result }, caption: mess.done }, { quoted: m })
uselimit()}
break
case 'jadizombie':
case 'tozombie': {
if (limitnya < 1) return m.reply(mess.limit)
if (!quoted) return m.reply(example('dengan mengirim foto'))
if (!/image/.test(mime)) return m.reply(example('dengan mengirim foto'))
m.reply(mess.wait)
let media = await quoted.download()
let anu = await catbox(media)
let dat = await fetchJson(`https://itzpire.com/tools/jadizombie?url=${anu}`)
await conn.sendMessage(m.chat, { image: { url: dat.result }, caption: mess.done }, { quoted: m })
uselimit()}
break
case 'readmore': {
if (limitnya < 1) return m.reply(mess.limit)
const more = String.fromCharCode(8206)
const readmore = more.repeat(4001)
 if (!q.includes('|')) return m.reply(example('teksnya|teksnya'))
const text1 = q.substring(0, q.indexOf('|') - 0)
const text2 = q.substring(q.lastIndexOf('|') + 1)
m.reply( text1 + readmore + text2)
uselimit()}
break
case 'q': case 'getq': {
if (limitnya < 1) return m.reply(mess.limit)
if (!isPremium) return m.reply(mess.premium)
if (!m.quoted) return m.reply(example('reply pesannya'))
let penis = JSON.stringify({ [m.quoted.mtype]: m.quoted }, null, 2)
let jeneng = `MessageData_${crypto.randomBytes(8).toString('hex')}.json`;
await fs.writeFileSync(jeneng, penis);
await m.reply(penis);
await conn.sendMessage(m.chat, {
document: {
url: `./${jeneng}`
},
fileName: jeneng,
mimetype: '*/*'
}, {
quoted: m
})
await fs.unlinkSync(jeneng)
uselimit()}
break
case 'cekprovider': {
if (limitnya < 1) return m.reply(mess.limit)
if (!isPremium) return m.reply(mess.premium)
try {
if (!args || !args[0]) {
return m.reply(example('nomornya'))
}
const nomorTelp = args[0];
const result = noTelp.getOperator(nomorTelp, true) // Menggunakan validasi karakter
const caption = `> *C E K - P R O V I D E R*

○ *Nomor Telepon:* ${nomorTelp}
○ *Operator:* ${result.operator}
○ *Kartu:* ${result.card}
○ *Message:* ${result.message}
○ *Valid:* ${result.valid ? 'Yes' : 'No'}`
conn.sendMessage(m.chat, { text: caption }, { quoted: m })
} catch (e) {
console.error(e)
m.reply(mess.error)
}
uselimit()}
break
case 'resolution':
case 'cekreso': {
if (limitnya < 1) return m.reply(mess.limit)
if (!/image/.test(mime)) return m.reply(example('dengan mengirim foto'))
m.reply(mess.wait)
let media = await quoted.download()
let source = await jimp.read(media)
let height = await source.getHeight()
let width = await source.getWidth()
pak = `*_RESOLUSI:_* ${width} x ${height}

*> Lebar :* ${width}
*> Tinggi :* ${height}`
conn.sendMessage(m.chat, {
text: pak,
contextInfo: {
externalAdReply: {
showAdAttribution: true,
title: `乂 C E K - R E S O L U T I O N`,
body: '',
thumbnailUrl: 'https://telegra.ph/file/cac47fc63dc63800630fa.jpg',
sourceUrl: null,
mediaType: 1,
renderLargerThumbnail: true
}}
})
uselimit()}
break
case 'sstohtml':
case 'tohtml': {
if (limitnya < 1) return m.reply(mess.limit)
if (!/image/.test(mime)) return m.reply(example('dengan mengirim foto'))
m.reply(mess.wait)
let media = await quoted.download()
let urlmedia = await catbox(media)
const data = {
imageUrl: urlmedia,
typecode: "html_css"
};
axios.post('https://luminai.my.id/screenshot-to-code', data)
.then(response => {
conn.sendMessage(m.chat, { text: response.data.result.data }, { quoted: m })
})
.catch(error => {
console.error('Error:', error);
});
uselimit()}
break
case 'sshp':
case 'sspc':
case 'sstab': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('linknya'))
m.reply(mess.wait)
conn.sendMessage(m.chat, { image: { url: `https://widipe.com/${command}?url=${text}` }, caption: mess.done }, { quoted: m })
uselimit()}
break

//================== [ PANEL MENU ] ==================//
case 'cpanel':
case 'addpanel':
case 'buatpanel': {
if (!panel && !isCreator) return m.reply(mess.panel)
if (global.domain.length < 1) return m.reply("Domain Tidak Ditemukan!")
if (global.apikey.length < 1) return m.reply("Apikey Tidak Ditemukan!")
if (!args[0] || !args[1]) return m.reply(example('namanya ramnya\n\n*List Ram :*\nunlimited | 1gb | 2gb | 3gb | 4gb | 5gb | 6gb | 7gb | 8gb | 9gb | 10gb'))
if (!isNaN(args[0])) return m.reply(example('namanya ramnya\n\n*List Ram :*\nunlimited | 1gb | 2gb | 3gb | 4gb | 5gb | 6gb | 7gb | 8gb | 9gb | 10gb'))
m.reply(mess.wait)
var ram
var disk
var cpu
if (args[1] == 'unlimited') {
ram = "0"
disk = "0"
cpu = "0"
} else if (args[1] == '1gb') {
ram = "1125"
disk = "1125"
cpu = "60"
} else if (args[1] == '2gb') {
ram = "2125"
disk = "2125"
cpu = "80"
} else if (args[1] == '3gb') {
ram = "3125"
disk = "3125"
cpu = "100"
} else if (args[1] == '4gb') {
ram = "4125"
disk = "4125"
cpu = "120"
} else if (args[1] == '5gb') {
ram = "5125"
disk = "5125"
cpu = "140"
} else if (args[1] == '6gb') {
ram = "6125"
disk = "6125"
cpu = "160"
} else if (args[1] == '7gb') {
ram = "7125"
disk = "7125"
cpu = "180"
} else if (args[1] == '8gb') {
ram = "8125"
disk = "8125"
cpu = "200"
} else if (args[1] == '9gb') {
ram = "9124"
disk = "9125"
cpu = "220"
} else if (args[1] == '10gb') {
ram = "10125"
disk = "10125"
cpu = "240"
}
let username = args[0].toLowerCase()
let email = username+"@gmail.com"
let name = capital(args[0])
let password = username+crypto.randomBytes(3).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = jam
let usr_id = user.id
let f1 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil Membuat Akun Panel ✅*\nData Akun Sudah Dikirim Ke Private Chat")
} else {
orang = m.chat
}
let teks = `*Berhasil Membuat Akun Panel ✅*

* *ID :* ${server.id}
* *UUID:* ${user.uuid}
* *Email :* ${user.email}
* *Name:* ${user.first_name} ${user.last_name}
* *Username :* ${user.username}
* *Password :* ${password.toString()}
* *Ram :* ${ram == "0" ? "Unlimited" : ram.charAt(0) + "GB"}
* *CPU :* ${cpu == "0" ? "Unlimited" : cpu+"%"}
* *Storage :* ${disk == "0" ? "Unlimited" : disk.charAt(0) + "GB"}
* *Language:* ${user.language}
* *Admin:* ${user.root_admin}
* *Created :* ${user.created_at}

*Link Login ⤵️*
${global.domain}`
conn.sendMessage(orang, { text: teks }, { quoted: qtoko })
}
break
case 'delpanel':
case 'hapuspanel': {
if (!isCreator) return m.reply(mess.owner)
if (global.domain.length < 1) return m.reply("Domain Tidak Ditemukan!")
if (global.apikey.length < 1) return m.reply("Apikey Tidak Ditemukan!")
if (!args[0]) return m.reply(example("idservernya\n\nuntuk melihat id server ketik *.listpanel*"))
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let result = await f.json()
let servers = result.data
let sections = []
for (let server of servers) {
let s = server.attributes
if (args[0] == s.id.toString()) {
sections.push(s.name.toLowerCase())
let f = await fetch(domain + `/api/application/servers/${s.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
}}
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
for (let user of users) {
let u = user.attributes
if (sections.includes(u.username)) {
let delusr = await fetch(domain + `/api/application/users/${u.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}}
if (sections.length == 0) return m.reply("*ID Server/User* Tidak Ditemukan")
m.reply(`Berhasil Menghapus Akun Panel *${capital(sections[0])}*`)
}
break
case 'listpanel':
case 'listuser':
case 'listserver': {
if (!isCreator) return m.reply(mess.owner)
if (global.domain.length < 1) return m.reply("Domain Tidak Ditemukan!")
if (global.apikey.length < 1) return m.reply("Apikey Tidak Ditemukan!")
if (global.capikey.length < 1) return m.reply("Capikey Tidak Ditemukan!")
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
});
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return m.reply("Tidak Ada Server Bot")
let messageText = "*🌐 LIST SERVER PANEL BOT*\n\n"
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikey
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;
messageText += `*┌ ◦* ID Server *${s.id}*\n`;
messageText += `*│ ◦* Nama Server *${s.name}*\n`
messageText += `*│ ◦* Ram *${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.length > 3 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}*\n`
messageText += `*│ ◦* CPU *${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}*\n`;
messageText += `*└ ◦* Storage *${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}*\n\n`
}
messageText += ` Total Server : *${res.meta.pagination.count} Server*`;
await conn.sendMessage(m.chat, { text: messageText }, { quoted: m })
}
break
case 'cpaneladmin':
case 'addadmin':
case 'buatadmin': {
if (!isCreator) return m.reply(mess.owner)
if (global.domain.length < 1) return m.reply("Domain Tidak Ditemukan!")
if (global.apikey.length < 1) return m.reply("Apikey Tidak Ditemukan!")
if (!text) return m.reply(example('namanya'))
let username = text.toLowerCase()
let email = username+"@gmail.com"
let name = capital(args[0])
let password = username+crypto.randomBytes(3).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil Membuat Akun Admin Panel ✅*\nData Akun Sudah Dikirim Ke Private Chat")
} else {
orang = m.chat
}
let teks = `*Berhasil Membuat Admin Panel ✅*

* *ID :* ${user.id}
* *UUID:* ${user.uuid}
* *Email :* ${user.email}
* *Name:* ${user.first_name} ${user.last_name}
* *Username :* ${user.username}
* *Password :* ${password.toString()}
* *Language:* ${user.language}
* *Admin:* ${user.root_admin}
* *Created At:* ${user.created_at}

*Link Login ⤵️*
${global.domain}`
conn.sendMessage(orang, { text: teks }, { quoted: qtoko })
}
break
case 'deladmin':
case 'hapusadmin': {
if (!isCreator) return m.reply(mess.owner)
if (global.domain.length < 1) return m.reply("Domain Tidak Ditemukan!")
if (global.apikey.length < 1) return m.reply("Apikey Tidak Ditemukan!")
if (!args[0]) return m.reply(example("id\n\nuntuk melihat id admin ketik *.listadmin*"))
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
let getid = null
let idadmin = null
await users.forEach(async (e) => {
if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
getid = e.attributes.username
idadmin = e.attributes.id
let delusr = await fetch(domain + `/api/application/users/${idadmin}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}
})
if (idadmin == null) return m.reply("ID Admin Tidak Ditemukan!")
m.reply(`Berhasil Menghapus Admin Panel *${capital(getid)}*`)
}
break
case 'listadmin': {
if (!isCreator) return m.reply(mess.owner)
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return m.reply("Tidak Ada Admin Panel")
var teks = "*🌐 LIST ADMIN PANEL*\n\n"
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
teks += `*┌ ◦* ID User *${i.attributes.id}*
*└ ◦* Nama *${i.attributes.first_name}*\n\n`
})
m.reply(teks)
}
break

//================== [ DOMAIN MENU ] ==================//
case 'listdomain': {
if (!subdo && !isCreator) return m.reply(mess.subdo)
var teks = `*List Domain Yang Tersedia :*

.domain1 ${global.subdomain.satu_subdomain.tld1}
.domain2 ${global.subdomain.dua_subdomain.tld2}
.domain3 ${global.subdomain.tiga_subdomain.tld3}

*Contoh Cara Membuat Subdomain :*
ketik *.domain1* hostname|ipvps

*Contoh Cara Melihat Subdomain :*
ketik *.listsubdomain domain1*
`
m.reply(teks)
}
break
case 'domain1':
case 'domain2':
case 'domain3': {
if (!subdo && !isCreator) return m.reply(mess.subdo)
if (!text) return m.reply(example("host|ip"))
if (!text.split("|")) return m.reply(example("host|ip"))
let zonenya
let apinya
let tldnya
let dom = args[0].toLowerCase()
if (/domain1/.test(command)) {
zonenya = global.subdomain.satu_subdomain.zone1
apinya = global.subdomain.satu_subdomain.apitoken1
tldnya = global.subdomain.satu_subdomain.tld1
} else if (/domain2/.test(command)) {
zonenya = global.subdomain.dua_subdomain.zone2
apinya = global.subdomain.dua_subdomain.apitoken2
tldnya = global.subdomain.dua_subdomain.tld2
} else if (/domain3/.test(command)) {
zonenya = global.subdomain.tiga_subdomain.zone3
apinya = global.subdomain.tiga_subdomain.apitoken3
tldnya = global.subdomain.tiga_subdomain.tld3
}
async function subDomain1(host, ip) {
return new Promise((resolve) => {
axios.post(
`https://api.cloudflare.com/client/v4/zones/${zonenya}/dns_records`,
{ type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tldnya, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
{
headers: {
Authorization: "Bearer " + apinya,
"Content-Type": "application/json",
},
}).then((e) => {
let res = e.data
if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content })
}).catch((e) => {
let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e
let err1Str = String(err1)
resolve({ success: false, error: err1Str })
})
})}
let raw1 = text
if (!raw1) return m.reply(example("host|ip"))
let host1 = raw1.split("|")[0].trim().replace(/[^a-z0-9.-]/gi, "")
if (!host1) return m.reply("Hostname Tidak Valid!, Hostname Hanya Mendukung Tanda Strip(-) Atau Titik(.)")
let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
if (!ip1 || ip1.split(".").length < 4) return m.reply(ip1 ? "IP Tidak Valid!" : "Isi IP Servernya!")
await subDomain1(host1.toLowerCase(), ip1).then((e) => {
if (e['success']) m.reply(`*Subdomain Berhasil Dibuat ✅*\n\n*Domain Induk 🌐*\n${tldnya}\n*IP 📡*\n${e['ip']}\n*Subdomain 🌐*\n${e['name']}`)
else m.reply(`${e['error']}`)
})}
break
case 'subfinder': {
if (!isCreator) return m.reply(mess.owner)
if (!text) return m.reply(example('google.com'))
let response = await axios.get(`https://api.agatz.xyz/api/subdomain?url=${text}`);
let list_domen = response.data.data.map((data, index) => {
return `${data}`;
}).join('\n');
let send_domain = `*List Domain ${text}*

${list_domen}`
m.reply(send_domain) 
}
break
case 'listsubdo':
case 'listsubdomain': {
if (!isCreator) return m.reply(mess.owner)
if (!args[0]) return m.reply(example("domain1\n\nketik *.listdomain*\nUntuk melihat list domainnya"))
let zonenya
let apinya
let dom = args[0].toLowerCase()
if (/domain1/.test(dom)) {
zonenya = global.subdomain.satu_subdomain.zone1
apinya = global.subdomain.satu_subdomain.apitoken1
} else if (/domain2/.test(dom)) {
zonenya = global.subdomain.dua_subdomain.zone2
apinya = global.subdomain.dua_subdomain.apitoken2
} else if (/domain3/.test(dom)) {
zonenya = global.subdomain.tiga_subdomain.zone3
apinya = global.subdomain.tiga_subdomain.apitoken3
}
axios.get(
`https://api.cloudflare.com/client/v4/zones/${zonenya}/dns_records`,{
headers: {
Authorization: "Bearer " + `${apinya}`,
"Content-Type": "application/json",
},
}).then(async (res) => {
if (res.data.result.length < 1) return m.reply("Tidak Ada Subdomain")
var teks = `*🌐 LIST SUBDOMAIN ${dom.toUpperCase()}*\n\n*Total Subdomain :* ${res.data.result.length}\n\n`
await res.data.result.forEach(e => teks += `*Domain :* ${e.name}\n*IP :* ${e.content}\n\n`)
return m.reply(teks)
})
}
break

//================== [ STORE MENU ] ==================//
case 'done': {
if (!isCreator) return m.reply(mess.owner)
if (!text) return m.reply(example('barang,harga\n\n*Contoh :* Panel Unlimited,2'))
if (!text.split(",")) return m.reply(example('barang,harga\n\n*Contoh :* Panel Unlimited,2'))
const [barang, harga] = text.split(",")
if (isNaN(harga)) return m.reply("Format Harga Tidak Valid")
var total = Number(`${harga}000`)
let teks = `*Transaksi Done By ${ownername} ✅*

*📦 Barang :* ${barang}
*💸 Nominal :* ${formatIDR(total)}
*🗓️ Tanggal :* ${tgl}
*⏰ Waktu :* ${jam}

_*Terimakasih Sudah Mempercayai & Menggunakan Jasa Saya 🥳*_`
m.reply(teks)
}
break
case 'proses': {
if (!isCreator) return m.reply(mess.owner)
const text12 = `
*━─━[ Transaksi Proses ]━─━*

Halo Kak
Sekarang Transaksi Kamu Sedang
Di Proses Mohon Tunggu 
Sebentar Yah 😅

─━─━─━─━─━─━─━─━─━─━─`
m.reply(text12)
}
break
case 'tunda': {
if (!isCreator) return m.reply(mess.owner)
const text12 = `
*━───━[ Transaksi Pending ]━───━*

Halo Kak
Transaksi Kamu Masih Dipending Nih 😓,
Tunggu Konfirmasi Selanjutnya Yah 😇

━───━━───━━───━━───━━───━`
m.reply(text12)
}
break
case 'batal': {
if (!isCreator) return m.reply(mess.owner)
const text12 = `
*━─━[ Transaksi Batal ]━─━*

Halo Kak

*🗓️ Tanggal :* ${tgl}
*⏰ Waktu :* ${jam}

Yah Transaksi Kamu Di Batalkan 😭
Semoga Lain Kali Berhasil 😊

─━─━─━─━─━─━─━─━─━─`
m.reply(text12)
}
break
case 'kalkulator': {
val = text
.replace(/[^0-9\-\/+*×÷πEe()piPI/]/g, '')
.replace(/×/g, '*')
.replace(/÷/g, '/')
.replace(/π|pi/gi, 'Math.PI')
.replace(/e/gi, 'Math.E')
.replace(/\/+/g, '/')
.replace(/\++/g, '+')
.replace(/-+/g, '-')
let format = val
.replace(/Math\.PI/g, 'π')
.replace(/Math\.E/g, 'e')
.replace(/\//g, '÷')
.replace(/\*×/g, '×')
try {
m.reply(mess.wait)
let result = (new Function('return ' + val))()
if (!result) return m.reply(result)
m.reply(`*${format}* = _${result}_`)
} catch (e) {
if (e == undefined) return m.reply('Isinya?')
m.reply('Format salah, hanya 0-9 dan Simbol -, +, *, /, ×, ÷, π, e, (, ) yang disupport')
}}
break
case 'buyprem': {
m.reply(`*💸 LIST HARGA USER PREMIUM*

*乂 PAKET A*
*Harga Rp3.000*
◦ Gratis Balance $10.000.000.000
◦ Gratis Limit 10.000
◦ Akses fitur premium
◦ Akses fitur claim limit & balance harian
◦ 10 hari akses premium

*乂 PAKET B*
*Harga Rp5.000*
◦ Gratis Balance $30.000.000.000
◦ Gratis Limit 20.000
◦ Akses fitur premium
◦ Akses fitur claim limit & balance harian
◦ 20 hari akses premium

*乂 PAKET C*
*Harga Rp8.000*
◦ Gratis Balance $50.000.000.000
◦ Gratis Limit 30.000
◦ Akses fitur premium
◦ Akses fitur claim limit & balance harian
◦ 30 hari akses premium

*Kegunaan User Premium :*
◦ *Bisa Akses Fitur Premium*
◦ *Bisa Akses Bot Didalam Private Chat*
◦ *Bisa Mendapatkan Limit Banyak*
◦ *Bisa Mendapatkan Balance Banyak*
◦ *Bisa Menggunakan Fitur Sesuka Hati Tanpa Limit Habis*

Hubungi owner bot untuk membeli paket *User Premium*`)}
break
case 'buysewa': {
m.reply(`*💸 LIST HARGA SEWA BOT*

*乂 PAKET A*
*Harga Rp10.000*
◦ Akses bot ke gc
◦ Akses fitur premium
◦ 10 Hari akses bot ke gc

*乂 PAKET B*
*Harga Rp15.000*
◦ Akses bot ke gc
◦ Akses fitur premium
◦ 20 Hari akses bot ke gc

*乂 PAKET C*
*Harga Rp20.000*
◦ Akses bot ke gc
◦ Akses fitur premium
◦ 30 Hari akses bot ke gc

*Kegunaan Sewa Bot :*
◦ *Bot Bisa Di Masukin Kedalam Group*
◦ *Bisa Menyambut Member Baru / Keluar*
◦ *Bisa Menghapus Pesan Member Jika Ada Yang Kirim Link*
◦ *Bisa Menghapus Pesan Member Jika Ada Yang Toxic*
◦ *Fast Response & Ada Error Langsung di perbaiki*

Hubungi owner bot untuk membeli paket *Sewa Bot*`)}
break

//================== [ AI MENU ] ==================//
case 'ai':
case 'openai': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('apa itu nodejs'))
let prompt = `kamu adalah ChatGpt, yang di kembangkan oleh team ChatGpt, kamu ramah, kamu bisa menjawab semua pertanyaan, kamu cerdas, kamu sekarang menggunakan jam ${jam}, tanggal ${tgl}, dan hari ${hari}.`
let Aii = await openai(text, prompt)
conn.sendMessage(m.chat, { text: Aii }, { quoted: m })
uselimit()}
break
case 'bard': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('apa itu nodejs'))
let res = await bardaifree(text)
conn.sendMessage(m.chat, { text: res }, { quoted: m })
uselimit()}
break
case 'bing': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('apa itu nodejs'))
let logic = `Nama kamu adalah Bing, kamu dibuat dan dikembangkan oleh microsoft. Gunakan bahasa gaul seperti kata gue dan lu dalam menjawab semua pertanyaan orang. kamu cerdas. Gunakan emoji yang sesuai dalam setiap kalimat. Gunakan tanggal ${tgl}. Gunakan jam ${jam}. Gunakan hari ${hari}.`
let d = await fetchJson(`https://itzpire.com/ai/bing-ai?model=Creative&q=${text}&logic=${logic}`)
conn.sendMessage(m.chat, { text: d.result }, { quoted: m })
uselimit()}
break
case 'turbo': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('apa itu nodejs'))
m.reply(mess.wait)
let res = await fetchJson(`https://widipe.com/turbo?text=${text}`)
conn.sendMessage(m.chat, { text: res.result }, { quoted: m })
uselimit()}
break
case 'sindy': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('apa itu nodejs'))
try {
let gpt = await fetchJson(`https://itzpire.com/ai/botika?q=${text}&user=${m.sender}&model=${command}`)
conn.sendMessage(m.chat, { text: "*[ SINDY - AI ]* " + '\n' + gpt.result }, { quoted: m })
} catch(e) {
return m.reply("`*Gpt Not Responded*`")
}
uselimit()}
break
case 'alicia': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('apa itu nodejs'))
try {
let gpt = await fetchJson(`https://itzpire.com/ai/botika?q=${text}&user=${m.sender}&model=${command}`)
conn.sendMessage(m.chat, { text: "*[ ALICIA - AI ]* " + '\n' + gpt.result })
} catch(e) {
return m.reply("`*Gpt Not Responded*`")
}
uselimit()}
break
case 'siska': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('apa itu nodejs'))
try {
let gpt = await fetchJson(`https://itzpire.com/ai/botika?q=${text}&user=${m.sender}&model=${command}`)
conn.sendMessage(m.chat, { text: "*[ SISKA - AI ]* " + '\n' + gpt.result }, { quoted: m })
} catch(e) {
return m.reply("`*Gpt Not Responded*`")
}
uselimit()}
break
case 'blackbox':
case 'bb': {
if (limitnya < 1) return m.reply(mess.limit)
if (!text) return m.reply(example('apa itu nodejs'))
try {           
let res = await blackboxChat(text)
conn.sendMessage(m.chat, { text: "*[ BLACKBOX - AI ]* " + '\n' + res }, { quoted: m })
} catch(e) {
return m.reply("`*Gpt Not Responded*`")
}
uselimit()}
break
default:
if (budy.startsWith('>')) {
if (!isCreator) return m.reply(mess.owner)
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
m.reply(String(err))
}
}

if (budy.startsWith("=>")) {
if (!isCreator) return m.reply(mess.owner)
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)
}
return m.reply(bang)
}
try {
m.reply(
util.format(eval(`(async () => { return ${budy.slice(3)} })()`)),
)
} catch (e) {
m.reply(String(e))
}
}
        
if (body.startsWith('$')) {
if (!isCreator) return m.reply(mess.owner)
qur = body.slice(2)
exec(qur, (err, stdout) => {
if (err) return m.reply(`${err}`)
if (stdout) {
m.reply(stdout)
}
})
}

}
} catch (err) {
conn.sendMessage(`${owner}@s.whatsapp.net`, { text: `*📢 Notifikasi Fitur Error :*\n\n${util.format(err)}` }, { quoted: m })}}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})