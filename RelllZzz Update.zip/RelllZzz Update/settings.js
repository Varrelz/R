/*
   * Script Dii WhatsApp - Bot
   * Created By DiiOffc 
*/

const fs = require('fs')
const chalk = require('chalk')

//================== [ SISTEM ] ==================//
global.sessionName = 'session' 
global.state = true

//================== [ OWNER & BOT ] ==================//
global.ownername = 'Varrel Bastian'
global.owner = '628893609279'
global.botname = 'RelllZzz BOTZ'

//================== [ LINK ] ==================//
global.linkgc = 'https://whatsapp.com/channel/0029VaghSW6E50UnFBX9Q62R'

//================== [ STICKER ] ==================//
global.packname = 'Created By'
global.author = 'RelllZzz BOTZ'

//================== [ THUMBNAIL ] ==================//
global.thumbnail = 'https://telegra.ph/file/80f0bc476f8b97c653f90.jpg'

//================== [ PANEL ] ==================//
global.domain = "https://"
global.apikey = "ptla_"
global.capikey = "ptlc_"
global.egg = "15"
global.loc = "1"

//================== [ DOMAIN MANAGE ] ==================//
global.subdomain = {
  satu_subdomain: {
    zone1: "95a92e2d61881587d97147504adae179",
    apitoken1: "Gh2ZG8DO7MoD7behXJc9NilacIdSv9o1BnMxiY-S",
    tld1: "mypanell-store.com"
  },
  dua_subdomain: {
    zone2: "5024bc4a02924cf69ddf4dfa6ee96069",
    apitoken2: "OajJ0jtCB0FTFwfdiTB_ktzNKFWAmsENFdlE4Hvd",
    tld2: "dewapanel.my.id"
  },
  tiga_subdomain: {
    zone3: "946d5f35d0657cb8bfa442675b37ec42",
    apitoken3: "9IJl3ihBj_McQT6aG0D5MBFQH3YmB1PO7Z34XLr1",
    tld3: "sellerpanel-vvip.my.id"
  }
}

//================== [ LIMIT & BALANCE ] ==================//
global.limitawal = 1000
global.balanceawal = 10000

//================== [ MESS ] ==================//
global.mess = {
    limit: (`❗Limit kamu sudah habis !\nketik .buylimit untuk membeli limit`),
    regis: (`❗Kamu belum daftar !\nSilahkan daftar dengan cara .daftar`),
    panel: ('❗Perintah Ini Khusus User Reseller Panel'),
    subdo: ('❗Perintah Ini Khusus User Reseller Subdo'),
    premium: ('❗️Perintah Ini Khusus User Premium'),
    owner: ('❗Perintah Ini Hanya Bisa Digunakan Oleh Owner !'),
    private: ('❗Perintah Ini Hanya Bisa Digunakan Di Private Chat !'),
    group: ('❗Perintah Ini Hanya Bisa Digunakan Di Group Chat !'),
    admin: ('❗Perintah Ini Hanya Bisa Digunakan Oleh Admin Group !'),
    botAdmin: ('❗Perintah Ini Hanya Bisa Digunakan Ketika Bot Menjadi Admin Group !'),
    banned: ('❗Kamu tidak bisa memakai fitur bot, Karna kamu telah di Banned !'),
    linkvalid: ('❗Link tautan tidak valid !'),
    error: ('❗Error terjadi kesalahan !'),
    wait: ('⏳Sedang Di proses !'),
    done: ('✅Berhasil Mengambil Data'),
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})